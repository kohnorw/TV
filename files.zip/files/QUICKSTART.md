# 🚀 Quick Start Guide - All-in-One Installer

## Complete Installation in 3 Steps

### Step 1: Upload Files to Server

Upload these files to your Ubuntu server:
- `install-all.sh`
- `plex_xtream_bridge_web.py`

**Using SCP:**
```bash
# From your local machine:
scp install-all.sh plex_xtream_bridge_web.py username@your-server-ip:~/
```

**Or download directly on server:**
```bash
# If you have files on GitHub:
wget https://raw.githubusercontent.com/YOUR_USER/YOUR_REPO/main/install-all.sh
wget https://raw.githubusercontent.com/YOUR_USER/YOUR_REPO/main/plex_xtream_bridge_web.py
```

### Step 2: Run Installer

```bash
# Make executable
chmod +x install-all.sh

# Run installer
bash install-all.sh
```

This will:
- ✅ Install Python 3 and dependencies
- ✅ Create virtual environment
- ✅ Install Flask, PlexAPI, Cryptography
- ✅ Setup directory structure
- ✅ Configure everything automatically

### Step 3: Install as Service

```bash
# Install as system service
bash install-all.sh --install-service
```

This will:
- ✅ Create systemd service
- ✅ Enable auto-start on boot
- ✅ Start the bridge immediately
- ✅ Show you the web interface URL

## 🎯 After Installation

### 1. Access Web Interface

Open browser to: `http://YOUR_SERVER_IP:8080/admin`

### 2. First Login

- **Password**: `admin123`
- **You'll be redirected** to create a new secure password
- **Enter new password** (minimum 8 characters)
- **Confirm password**
- **Click "Set Password & Continue"**

### 3. Configure Plex

Click **"⚙️ Settings"** and enter:
- **Plex Server URL**: `http://192.168.1.100:32400`
- **Plex Token**: Get from Plex Web (see below)
- **Bridge Username**: Choose any username
- **Bridge Password**: Choose any password
- **TMDb API Key**: (Optional) Get free key from themoviedb.org

Click **"💾 Save Settings"**

### 4. Add to Your Player

Configure your Xtream UI player with:
- **URL**: `http://YOUR_SERVER_IP:8080`
- **Username**: What you set in Bridge Username
- **Password**: What you set in Bridge Password

### 5. Enjoy!

Your player will now show:
- 📁 All your Plex libraries
- 🆕 Recently Added categories
- 🎬 Recently Released categories
- ⭐ Highly Rated categories
- 🎭 All genres as separate categories

## 🔑 Getting Your Plex Token

### Method 1: From Plex Web
1. Go to https://app.plex.tv
2. Play any media
3. Click (...) → "Get Info" → "View XML"
4. In URL, copy value after `X-Plex-Token=`

### Method 2: From Server
```bash
sudo cat "/var/lib/plexmediaserver/Library/Application Support/Plex Media Server/Preferences.xml" | grep -oP 'PlexOnlineToken="\K[^"]*'
```

## 🎮 Service Management

```bash
# Start
sudo systemctl start plex-xtream-bridge

# Stop
sudo systemctl stop plex-xtream-bridge

# Restart
sudo systemctl restart plex-xtream-bridge

# Status
sudo systemctl status plex-xtream-bridge

# View Logs
sudo journalctl -u plex-xtream-bridge -f
```

## 🔒 Security Features

### What's Protected:
- 🔐 **Plex Token** - AES-256 encrypted
- 🔐 **TMDb API Key** - AES-256 encrypted
- 🔐 **Admin Password** - SHA-256 hashed
- 🔐 **Config Files** - 600 permissions

### First Login Security:
- ⚠️ **Cannot use default password**
- ⚠️ **Forced to create secure password**
- ⚠️ **Minimum 8 characters**
- ⚠️ **Passwords are hashed**

## 📱 Compatible Players

Works with any Xtream Codes player:
- **TiviMate** (Android, FireTV) ⭐ Recommended
- **IPTV Smarters Pro** (iOS, Android, FireTV)
- **GSE Smart IPTV** (iOS, Android)
- **Perfect Player** (Android)
- **IPTV Extreme** (Android)

## 🎯 What You Get

### Features:
- ✅ Web interface for configuration
- ✅ Auto-generated categories
- ✅ Genre-based organization
- ✅ Recently added/released/rated
- ✅ Encrypted sensitive data
- ✅ Secure password management
- ✅ All your Plex movies & shows
- ✅ Live TV support (with Plex DVR)

### Categories Generated:
For each library:
- 🆕 Recently Added
- 🎬 Recently Released
- ⭐ Highly Rated
- 🎭 Action
- 🎭 Comedy
- 🎭 Drama
- 🎭 Horror
- 🎭 Sci-Fi
- 🎭 (All your genres)

## 🔧 Troubleshooting

### Can't Access Web Interface?
```bash
# Check if service is running
sudo systemctl status plex-xtream-bridge

# Check firewall
sudo ufw status

# Allow port if needed
sudo ufw allow 8080/tcp
```

### Plex Won't Connect?
```bash
# Test Plex URL
curl "http://YOUR_PLEX_IP:32400?X-Plex-Token=YOUR_TOKEN"

# Check Plex is running
sudo systemctl status plexmediaserver
```

### Forgot Admin Password?
```bash
cd ~/plex-xtream-bridge
rm config.json
sudo systemctl restart plex-xtream-bridge
# Default password restored: admin123
```

### View Detailed Logs?
```bash
# Live logs
sudo journalctl -u plex-xtream-bridge -f

# Recent logs
sudo journalctl -u plex-xtream-bridge -n 100

# Errors only
sudo journalctl -u plex-xtream-bridge -p err
```

## 📊 File Locations

```
~/plex-xtream-bridge/
├── plex_xtream_bridge_web.py  # Main application
├── config.json                # Configuration (encrypted)
├── .encryption_key            # Encryption key (keep safe!)
├── categories.json            # Custom categories
├── requirements.txt           # Python dependencies
└── venv/                      # Virtual environment
```

## 🔄 Updating

```bash
# Stop service
sudo systemctl stop plex-xtream-bridge

# Backup
cd ~/plex-xtream-bridge
cp config.json config.json.backup
cp .encryption_key .encryption_key.backup

# Download new version
# ... copy new plex_xtream_bridge_web.py ...

# Restart
sudo systemctl start plex-xtream-bridge
```

## ⚡ Quick Commands

```bash
# Complete fresh install
bash install-all.sh --install-service

# Just setup (no service)
bash install-all.sh

# Check if running
sudo systemctl is-active plex-xtream-bridge

# Restart service
sudo systemctl restart plex-xtream-bridge

# View live logs
sudo journalctl -u plex-xtream-bridge -f

# Test API
curl http://localhost:8080

# Find server IP
hostname -I

# Allow firewall
sudo ufw allow 8080/tcp
```

## 📚 Full Documentation

For complete details, see:
- **UBUNTU_WEB_SETUP.md** - Detailed setup guide
- **SECURITY_GUIDE.md** - Security features explained
- **CATEGORIES_GUIDE.md** - How categories work
- **DUMMY_CHANNEL_GUIDE.md** - Live TV info
- **UPDATE_GUIDE.md** - Updating instructions

## 🎉 That's It!

You now have:
- ✅ Secure Plex bridge running
- ✅ Web interface for management
- ✅ Auto-organized categories
- ✅ Encrypted sensitive data
- ✅ Ready to use in any Xtream player

**Enjoy your beautifully organized Plex library!** 🎬📺
