#!/bin/bash
# Plex Xtream Bridge - All-in-One Installer for Ubuntu 22.04
# Includes: Web Interface, Categories, Security Features

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

echo -e "${BLUE}"
echo "============================================================"
echo "  Plex Xtream Bridge - All-in-One Installer"
echo "  Features: Web UI, Auto Categories, Security"
echo "============================================================"
echo -e "${NC}"

# Check if running as root
if [ "$EUID" -eq 0 ]; then 
    echo -e "${RED}Please do not run as root. Run as your regular user.${NC}"
    echo "Example: bash install-all.sh"
    exit 1
fi

INSTALL_DIR="$HOME/plex-xtream-bridge"

echo -e "${CYAN}[1/8] Checking system...${NC}"
if [ -f /etc/os-release ]; then
    . /etc/os-release
    if [[ "$ID" != "ubuntu" ]] && [[ "$ID_LIKE" != *"ubuntu"* ]]; then
        echo -e "${YELLOW}Warning: This script is designed for Ubuntu. Your system: $ID${NC}"
        read -p "Continue anyway? (y/N): " continue
        if [[ ! "$continue" =~ ^[Yy]$ ]]; then
            exit 1
        fi
    fi
fi

echo -e "${GREEN}[2/8] Updating system packages...${NC}"
sudo apt update -qq

echo -e "${GREEN}[3/8] Installing dependencies...${NC}"
echo "This may take a few minutes..."
sudo apt install -y python3 python3-pip python3-venv curl wget > /dev/null 2>&1

echo -e "${GREEN}[4/8] Creating installation directory...${NC}"
if [ -d "$INSTALL_DIR" ]; then
    echo -e "${YELLOW}Directory $INSTALL_DIR already exists.${NC}"
    read -p "Backup existing installation? (Y/n): " backup
    if [[ ! "$backup" =~ ^[Nn]$ ]]; then
        BACKUP_DIR="${INSTALL_DIR}_backup_$(date +%Y%m%d_%H%M%S)"
        echo "Creating backup at $BACKUP_DIR"
        cp -r "$INSTALL_DIR" "$BACKUP_DIR"
        echo -e "${GREEN}✓ Backup created${NC}"
    fi
else
    mkdir -p "$INSTALL_DIR"
fi

cd "$INSTALL_DIR"

echo -e "${GREEN}[5/8] Setting up Python virtual environment...${NC}"
if [ ! -d "venv" ]; then
    python3 -m venv venv
fi

source venv/bin/activate

echo -e "${GREEN}[6/8] Installing Python packages...${NC}"
pip install --quiet --upgrade pip

# Check if requirements.txt exists
if [ -f "requirements.txt" ]; then
    echo "Found requirements.txt, installing from file..."
    pip install --quiet -r requirements.txt
else
    echo "Installing packages individually..."
    pip install --quiet flask==3.0.0 plexapi==4.15.7 requests==2.31.0 cryptography==41.0.7
    
    # Create requirements.txt for future use
    cat > requirements.txt << 'EOF'
flask==3.0.0
plexapi==4.15.7
requests==2.31.0
cryptography==41.0.7
EOF
fi

echo -e "${GREEN}[7/8] Checking for bridge file...${NC}"

# Check if bridge file exists
if [ ! -f "$INSTALL_DIR/plex_xtream_bridge_web.py" ]; then
    echo -e "${YELLOW}Bridge file not found in $INSTALL_DIR${NC}"
    echo ""
    echo "The installer expects 'plex_xtream_bridge_web.py' to be in the same directory."
    echo ""
    echo -e "${CYAN}Options:${NC}"
    echo "1. Place plex_xtream_bridge_web.py in $INSTALL_DIR"
    echo "2. Run this installer from the directory containing the file"
    echo "3. Download from a URL"
    echo ""
    
    read -p "Do you want to download from a URL? (y/N): " download_choice
    if [[ "$download_choice" =~ ^[Yy]$ ]]; then
        read -p "Enter download URL: " download_url
        if [ ! -z "$download_url" ]; then
            echo "Downloading..."
            if command -v curl &> /dev/null; then
                curl -L -o "$INSTALL_DIR/plex_xtream_bridge_web.py" "$download_url"
            elif command -v wget &> /dev/null; then
                wget -O "$INSTALL_DIR/plex_xtream_bridge_web.py" "$download_url"
            else
                echo -e "${RED}Neither curl nor wget found. Cannot download.${NC}"
                exit 1
            fi
            
            if [ -f "$INSTALL_DIR/plex_xtream_bridge_web.py" ]; then
                echo -e "${GREEN}✓ Downloaded successfully${NC}"
            else
                echo -e "${RED}✗ Download failed${NC}"
                exit 1
            fi
        fi
    else
        echo ""
        echo -e "${YELLOW}Please copy plex_xtream_bridge_web.py to:${NC}"
        echo "  $INSTALL_DIR/plex_xtream_bridge_web.py"
        echo ""
        echo "Then run this installer again."
        exit 1
    fi
fi

echo -e "${GREEN}✓ Bridge file found!${NC}"

echo -e "${GREEN}[8/8] Setting up configuration...${NC}"

# Make bridge executable
chmod +x plex_xtream_bridge_web.py

# Get server IP
SERVER_IP=$(hostname -I | awk '{print $1}')

echo ""
echo -e "${GREEN}============================================================"
echo "  Installation Complete!"
echo "============================================================${NC}"
echo ""
echo -e "${CYAN}Installation Details:${NC}"
echo "  Location: $INSTALL_DIR"
echo "  Python: $(python3 --version)"
echo "  Packages: flask, plexapi, requests, cryptography"
echo ""
echo -e "${CYAN}What's Included:${NC}"
echo "  ✓ Web Interface for easy configuration"
echo "  ✓ Auto-generated smart categories"
echo "  ✓ Genre-based organization"
echo "  ✓ Encrypted API keys and tokens"
echo "  ✓ Secure password hashing"
echo "  ✓ Forced password change on first login"
echo ""
echo -e "${YELLOW}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""
echo -e "${CYAN}Next Steps:${NC}"
echo ""
echo -e "${GREEN}Option 1: Test run (manual)${NC}"
echo "  cd $INSTALL_DIR"
echo "  source venv/bin/activate"
echo "  python3 plex_xtream_bridge_web.py"
echo ""
echo -e "${GREEN}Option 2: Install as system service (recommended)${NC}"
echo "  bash $0 --install-service"
echo ""
echo -e "${YELLOW}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""
echo -e "${CYAN}After Starting:${NC}"
echo -e "  1. Access web interface: ${GREEN}http://$SERVER_IP:8080/admin${NC}"
echo -e "  2. Login with: ${GREEN}admin123${NC}"
echo -e "  3. ${YELLOW}You'll be forced to create a secure password${NC}"
echo -e "  4. Configure Plex URL and token"
echo -e "  5. Refresh your Xtream player"
echo ""
echo -e "${CYAN}Security Features:${NC}"
echo -e "  🔒 API keys encrypted with AES-256"
echo -e "  🔒 Passwords hashed with SHA-256"
echo -e "  🔒 Restricted file permissions (600)"
echo -e "  🔒 Forced password change on first login"
echo ""

# Check if --install-service flag is present
if [ "$1" == "--install-service" ]; then
    echo ""
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${CYAN}Installing as System Service...${NC}"
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo ""
    
    ACTUAL_USER="${USER}"
    
    echo "Creating systemd service file..."
    sudo tee /etc/systemd/system/plex-xtream-bridge.service > /dev/null << EOF
[Unit]
Description=Plex to Xtream Codes API Bridge (Web Version with Security)
After=network.target

[Service]
Type=simple
User=$ACTUAL_USER
WorkingDirectory=$INSTALL_DIR
ExecStart=$INSTALL_DIR/venv/bin/python3 $INSTALL_DIR/plex_xtream_bridge_web.py
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF
    
    echo "Reloading systemd daemon..."
    sudo systemctl daemon-reload
    
    echo "Enabling service to start on boot..."
    sudo systemctl enable plex-xtream-bridge.service
    
    echo "Starting service..."
    sudo systemctl start plex-xtream-bridge.service
    
    # Wait a moment for service to start
    sleep 3
    
    echo ""
    echo -e "${GREEN}============================================================"
    echo "  Service Installed and Started!"
    echo "============================================================${NC}"
    echo ""
    
    # Check service status
    if sudo systemctl is-active --quiet plex-xtream-bridge.service; then
        echo -e "${GREEN}✓ Service is running${NC}"
    else
        echo -e "${RED}✗ Service failed to start${NC}"
        echo ""
        echo "Check logs with:"
        echo "  sudo journalctl -u plex-xtream-bridge -n 50"
    fi
    
    echo ""
    echo -e "${CYAN}Service Management Commands:${NC}"
    echo -e "  ${GREEN}Start:${NC}   sudo systemctl start plex-xtream-bridge"
    echo -e "  ${GREEN}Stop:${NC}    sudo systemctl stop plex-xtream-bridge"
    echo -e "  ${GREEN}Restart:${NC} sudo systemctl restart plex-xtream-bridge"
    echo -e "  ${GREEN}Status:${NC}  sudo systemctl status plex-xtream-bridge"
    echo -e "  ${GREEN}Logs:${NC}    sudo journalctl -u plex-xtream-bridge -f"
    echo ""
    echo -e "${CYAN}Web Interface:${NC}"
    echo -e "  ${GREEN}http://$SERVER_IP:8080/admin${NC}"
    echo ""
    echo -e "${CYAN}Default Login:${NC}"
    echo -e "  Password: ${GREEN}admin123${NC}"
    echo -e "  ${YELLOW}⚠️  You'll be required to change this on first login!${NC}"
    echo ""
    echo -e "${CYAN}Firewall Setup (if needed):${NC}"
    echo -e "  sudo ufw allow 8080/tcp"
    echo -e "  # Or restrict to local network:"
    echo -e "  sudo ufw allow from 192.168.1.0/24 to any port 8080"
    echo ""
    echo -e "${GREEN}🎉 Your bridge is now running!${NC}"
    echo ""
fi

echo -e "${YELLOW}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""
echo -e "${CYAN}Documentation:${NC}"
echo -e "  Setup Guide:     UBUNTU_WEB_SETUP.md"
echo -e "  Security Guide:  SECURITY_GUIDE.md"
echo -e "  Categories:      CATEGORIES_GUIDE.md"
echo ""
echo -e "${CYAN}Need Help?${NC}"
echo -e "  Check the logs: sudo journalctl -u plex-xtream-bridge -f"
echo -e "  Test API: curl http://localhost:8080"
echo ""
echo -e "${GREEN}Installation script completed successfully!${NC}"
echo ""
