# 🎬 TMDb Metadata Integration Guide

## 🎉 What's New

Your bridge now automatically fetches enhanced metadata from The Movie Database (TMDb) for all your movies and TV shows!

## ✨ Enhanced Metadata Includes:

### For Movies:
- 🎬 **TMDb & IMDb IDs** - Official database identifiers
- 📝 **Better Descriptions** - Detailed plot summaries
- ⭐ **TMDb Ratings** - Community ratings and vote counts
- 🎭 **Complete Cast & Crew** - Top 10 actors with character names
- 🎥 **Directors** - Accurate director information
- 🏷️ **Keywords** - Searchable tags
- 🖼️ **High-Quality Posters** - Original resolution artwork
- 🌄 **Backdrops** - Beautiful background images
- 📺 **Trailers** - YouTube trailer links
- 💬 **Taglines** - Movie taglines
- 📊 **Popularity Scores** - Trending information

### For TV Shows:
- 📺 **TMDb IDs** - Official database identifiers
- 📝 **Better Descriptions** - Detailed show summaries
- ⭐ **TMDb Ratings** - Community ratings
- 🎭 **Complete Cast** - Top 10 actors with roles
- 👤 **Creators** - Show creators/producers
- 📡 **Networks** - Original broadcasting networks
- 📊 **Episode Counts** - Total seasons and episodes
- 🏷️ **Keywords** - Searchable tags
- 🖼️ **Posters & Backdrops** - High-quality imagery
- 📺 **Trailers** - YouTube trailer links
- 📈 **Status** - Returning/Ended/Cancelled

## 🔑 Getting Your TMDb API Key

### Step 1: Create TMDb Account
1. Go to https://www.themoviedb.org
2. Click "Sign Up" (top right)
3. Complete registration (it's free!)
4. Verify your email

### Step 2: Request API Key
1. Go to https://www.themoviedb.org/settings/api
2. Click "Request an API Key"
3. Choose "Developer"
4. Fill out the form:
   - **Application Name**: Plex Xtream Bridge
   - **Application URL**: http://localhost (or your URL)
   - **Application Summary**: Personal Plex to Xtream bridge
5. Agree to terms
6. Submit

### Step 3: Copy Your API Key
1. You'll see "API Key (v3 auth)"
2. Copy the key (looks like: `a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6`)
3. Keep this safe!

## ⚙️ Adding API Key to Bridge

### Via Web Interface:
1. Go to `http://YOUR_SERVER_IP:8080/admin`
2. Login
3. Click **"⚙️ Settings"**
4. Scroll to **"Plex Server Configuration"**
5. Find **"TMDb API Key"** field
6. Paste your API key
7. Click **"💾 Save Settings"**
8. Done! Metadata will be fetched automatically

## 📊 How It Works

### Automatic Enhancement:
When you request movie/show information:

1. **Bridge fetches from Plex** - Gets basic info
2. **Searches TMDb** - Matches by title and year
3. **Enriches metadata** - Adds enhanced information
4. **Returns combined data** - Best of both sources

### Smart Fallbacks:
- If TMDb key not configured → Uses Plex metadata
- If TMDb match not found → Falls back to Plex data
- If API limit reached → Continues with Plex data
- No errors, just graceful degradation!

## 🎯 What You'll See in Your Player

### Before (Plex only):
```json
{
  "name": "Inception",
  "rating": "8.5",
  "plot": "Basic description from Plex",
  "director": "Christopher Nolan",
  "cast": "Leonardo DiCaprio, ..."
}
```

### After (With TMDb):
```json
{
  "name": "Inception",
  "tmdb_id": "27205",
  "imdb_id": "tt1375666",
  "rating": "8.367",
  "vote_count": "34567",
  "plot": "Detailed plot from TMDb...",
  "tagline": "Your mind is the scene of the crime",
  "director": "Christopher Nolan",
  "cast": "Leonardo DiCaprio (Cobb), Tom Hardy (Eames), ...",
  "keywords": "dream, heist, subconscious, ...",
  "youtube_trailer": "https://www.youtube.com/watch?v=...",
  "poster_path": "https://image.tmdb.org/t/p/original/...",
  "backdrop_path": "https://image.tmdb.org/t/p/original/...",
  "popularity": "89.234"
}
```

## 🖼️ Enhanced Images

### Poster Quality:
- **Before**: Plex posters (varies)
- **After**: TMDb original resolution (up to 2000px)

### Backdrop Images:
- **Before**: Plex art
- **After**: TMDb high-resolution backdrops

Your player will display beautiful, high-quality artwork!

## ⚡ Performance

### Caching:
- Metadata is fetched on-demand
- First load may be slightly slower
- Subsequent loads are instant
- API calls are minimized

### Rate Limits:
TMDb free tier allows:
- **40 requests per 10 seconds**
- **Unlimited daily requests**
- More than enough for personal use!

## 🎬 Use Cases

### Better Recommendations:
With keywords and popularity scores, you can:
- Find similar movies
- Discover trending content
- Search by themes

### Rich Metadata:
Players that support it will show:
- Trailers
- High-quality artwork
- Detailed cast information
- Plot summaries

### Enhanced Browsing:
Better metadata means:
- More accurate search results
- Better category suggestions
- Improved recommendations

## 🔧 Testing TMDb Integration

### Test API Key:
```bash
# Test your API key directly
curl "https://api.themoviedb.org/3/movie/27205?api_key=YOUR_API_KEY"

# Should return Inception's data
```

### Check Bridge Logs:
```bash
# Watch for TMDb fetches
sudo journalctl -u plex-xtream-bridge -f | grep TMDb

# You'll see:
# "Fetching TMDb data for: Inception"
# "✓ TMDb data fetched successfully"
```

### In Your Player:
1. Browse to a movie
2. Check movie details
3. Look for:
   - IMDb/TMDb IDs
   - Enhanced descriptions
   - Trailer links
   - Better artwork

## 🛠️ Troubleshooting

### "No TMDb Data" in Logs:

**Cause**: API key not set or invalid

**Solution**:
```bash
# Check your config
cat ~/plex-xtream-bridge/config.json | grep tmdb

# Verify API key works
curl "https://api.themoviedb.org/3/configuration?api_key=YOUR_KEY"
```

### Movies Not Matching:

**Cause**: Title mismatch between Plex and TMDb

**Solution**:
- TMDb searches by title and year
- Ensure Plex has correct year metadata
- Check Plex title matches TMDb title
- Most movies will still match automatically

### API Rate Limit:

**Cause**: Too many requests (rare)

**Solution**:
- Wait 10 seconds
- Bridge will automatically retry
- Free tier is very generous
- Consider upgrading TMDb account if needed

## 💡 Tips & Tricks

### Maximize Metadata Quality:

1. **Keep Plex Updated** - Better metadata to start with
2. **Fix Plex Matches** - Correct title/year improves TMDb matching
3. **Use Plex Scanner** - Scan libraries regularly
4. **Check TMDb Directly** - Verify movie exists on TMDb

### Optional: TMDb Account Benefits:

Free account includes:
- ✅ Unlimited API requests
- ✅ Access to all metadata
- ✅ High-quality images
- ✅ Trailer links

Paid account ($5/month) adds:
- No rate limits
- Early access features
- Support TMDb development

## 📊 Metadata Comparison

| Feature | Plex Only | With TMDb |
|---------|-----------|-----------|
| **Title** | ✅ | ✅ Enhanced |
| **Plot** | ✅ Basic | ✅ Detailed |
| **Rating** | ✅ Plex | ✅ TMDb + Votes |
| **Cast** | ✅ Names | ✅ Names + Characters |
| **Director** | ✅ | ✅ Enhanced |
| **Genres** | ✅ | ✅ Enhanced |
| **Posters** | ✅ | ✅ High-Res |
| **Backdrops** | ✅ | ✅ High-Res |
| **TMDb ID** | ❌ | ✅ |
| **IMDb ID** | ❌ | ✅ |
| **Trailers** | ❌ | ✅ YouTube Links |
| **Keywords** | ❌ | ✅ |
| **Taglines** | ❌ | ✅ |
| **Popularity** | ❌ | ✅ |
| **Vote Count** | ❌ | ✅ |

## 🎉 Summary

With TMDb integration:
- ✅ Richer metadata for all content
- ✅ High-quality artwork
- ✅ Trailer links
- ✅ Better ratings and cast info
- ✅ Enhanced browsing experience
- ✅ Free to use
- ✅ Automatic fallbacks
- ✅ No configuration after setup

Get your free API key and enjoy enhanced metadata! 🎬
