# Plex Xtream Bridge with Web Interface - Ubuntu 22.04 Setup

## 🎉 New Feature: Web Interface!

This version includes a beautiful web interface for easy configuration. No more editing config files manually!

## Quick Setup (5 Minutes)

### Step 1: Install Prerequisites

```bash
# Update system
sudo apt update

# Install Python and dependencies
sudo apt install -y python3 python3-pip python3-venv
```

### Step 2: Setup the Bridge

```bash
# Create directory
mkdir -p ~/plex-xtream-bridge
cd ~/plex-xtream-bridge

# Copy the files here (plex_xtream_bridge_web.py, requirements.txt)

# Create virtual environment
python3 -m venv venv

# Activate it
source venv/bin/activate

# Install dependencies
pip install flask plexapi requests
```

### Step 3: Run the Bridge

```bash
# Run it!
python3 plex_xtream_bridge_web.py
```

You'll see:
```
============================================================
Plex to Xtream Codes API Bridge with Web Interface
============================================================
Web Interface: http://0.0.0.0:8080/admin
Default Admin Password: admin123
API Endpoint: http://0.0.0.0:8080/player_api.php
Bridge Username: admin
Bridge Password: admin
============================================================

⚠️  IMPORTANT: Change the admin password after first login!
============================================================
```

### Step 4: Configure via Web Interface

1. **Find your server's IP address:**
   ```bash
   hostname -I
   ```

2. **Open the web interface:**
   - Open your browser
   - Go to: `http://YOUR_SERVER_IP:8080/admin`
   - Login with password: `admin123`

3. **Configure Plex:**
   - Click "⚙️ Settings"
   - Enter your Plex Server URL (e.g., `http://192.168.1.100:32400`)
   - Enter your Plex Token (see below for how to get it)
   - Set your Bridge Username/Password for Xtream players
   - Change the Admin Password (important!)
   - Click "💾 Save Settings"

4. **Done!** The dashboard will show your connected Plex libraries.

## Getting Your Plex Token

### Method 1: From Plex Web (Easiest)
1. Go to https://app.plex.tv
2. Play any media
3. Click (...) → "Get Info" → "View XML"
4. In the URL bar, copy the token after `X-Plex-Token=`

### Method 2: From Command Line
```bash
# Check your Plex preferences
sudo cat "/var/lib/plexmediaserver/Library/Application Support/Plex Media Server/Preferences.xml" | grep -oP 'PlexOnlineToken="\K[^"]*'
```

## Web Interface Features

### 📊 Dashboard
- View Plex connection status
- See all your libraries and item counts
- Monitor active connections
- Quick access to all settings

### ⚙️ Settings Page
- Easy Plex configuration
- Set bridge credentials for players
- Change admin password
- Test connection button

### 🧪 Test Connection
- Instantly verify Plex connectivity
- See server version and libraries
- Troubleshoot connection issues

## Running as a System Service

### Automated Setup

Create this file: `setup_service_web.sh`

```bash
#!/bin/bash
set -e

if [ "$EUID" -ne 0 ]; then 
    echo "Please run with sudo"
    exit 1
fi

ACTUAL_USER="${SUDO_USER:-$USER}"
USER_HOME=$(eval echo ~$ACTUAL_USER)
INSTALL_DIR="$USER_HOME/plex-xtream-bridge"

cat > /etc/systemd/system/plex-xtream-bridge.service << EOF
[Unit]
Description=Plex to Xtream Codes API Bridge (Web Version)
After=network.target

[Service]
Type=simple
User=$ACTUAL_USER
WorkingDirectory=$INSTALL_DIR
ExecStart=$INSTALL_DIR/venv/bin/python3 $INSTALL_DIR/plex_xtream_bridge_web.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable plex-xtream-bridge
systemctl start plex-xtream-bridge

echo "Service installed! Access web interface at http://$(hostname -I | awk '{print $1}'):8080/admin"
echo "Default password: admin123"
```

Run it:
```bash
chmod +x setup_service_web.sh
sudo ./setup_service_web.sh
```

### Manual Service Setup

```bash
sudo nano /etc/systemd/system/plex-xtream-bridge.service
```

Add:
```ini
[Unit]
Description=Plex to Xtream Codes API Bridge (Web Version)
After=network.target

[Service]
Type=simple
User=YOUR_USERNAME
WorkingDirectory=/home/YOUR_USERNAME/plex-xtream-bridge
ExecStart=/home/YOUR_USERNAME/plex-xtream-bridge/venv/bin/python3 /home/YOUR_USERNAME/plex-xtream-bridge/plex_xtream_bridge_web.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

Enable and start:
```bash
sudo systemctl daemon-reload
sudo systemctl enable plex-xtream-bridge
sudo systemctl start plex-xtream-bridge
sudo systemctl status plex-xtream-bridge
```

## Service Management

```bash
# Start
sudo systemctl start plex-xtream-bridge

# Stop
sudo systemctl stop plex-xtream-bridge

# Restart
sudo systemctl restart plex-xtream-bridge

# Status
sudo systemctl status plex-xtream-bridge

# Logs
sudo journalctl -u plex-xtream-bridge -f
```

## Firewall Setup

```bash
# Allow web interface and API
sudo ufw allow 8080/tcp

# Reload
sudo ufw reload
```

## Configuration File

Settings are saved to `config.json` in the bridge directory. You can:

- Edit via web interface (recommended)
- Edit the file directly (for advanced users)
- Set environment variables (for containers)

## Accessing the Bridge

### Web Interface
- URL: `http://YOUR_SERVER_IP:8080/admin`
- Login: Use admin password (default: `admin123`)

### For Xtream Players
- URL: `http://YOUR_SERVER_IP:8080`
- Username: Set in web interface (default: `admin`)
- Password: Set in web interface (default: `admin`)

## Security Tips

1. **Change default passwords immediately!**
   - Admin password (web interface)
   - Bridge password (for players)

2. **Use firewall rules:**
   ```bash
   # Only allow from your local network
   sudo ufw allow from 192.168.1.0/24 to any port 8080
   ```

3. **Consider reverse proxy with SSL:**
   - Use nginx or caddy
   - Add HTTPS certificate
   - Add authentication layer

## Troubleshooting

### Can't access web interface
```bash
# Check if service is running
sudo systemctl status plex-xtream-bridge

# Check logs
sudo journalctl -u plex-xtream-bridge -n 50

# Check if port is open
sudo netstat -tulpn | grep 8080

# Check firewall
sudo ufw status
```

### Plex won't connect
1. Check URL format: `http://IP:32400` (no trailing slash)
2. Verify token is correct
3. Test from command line:
   ```bash
   curl "http://YOUR_PLEX_IP:32400/?X-Plex-Token=YOUR_TOKEN"
   ```
4. Check firewall on Plex server

### Players won't connect
1. Verify bridge is running
2. Test API endpoint:
   ```bash
   curl "http://YOUR_BRIDGE_IP:8080/player_api.php?username=admin&password=admin"
   ```
3. Check credentials match what's in settings
4. Verify firewall allows connections

## Advantages of Web Version

✅ **Easy Configuration** - No config file editing
✅ **Visual Dashboard** - See your libraries at a glance  
✅ **Test Connection** - Instant Plex connectivity verification
✅ **Secure** - Password-protected admin panel
✅ **Settings Saved** - Configuration persists in `config.json`
✅ **Status Monitoring** - See active connections
✅ **User-Friendly** - Perfect for non-technical users

## What's Next?

1. Access the web interface
2. Configure your Plex connection
3. Set secure passwords
4. Add to your Xtream player
5. Enjoy your Plex library!

## Need Help?

Check the logs:
```bash
# Live logs
sudo journalctl -u plex-xtream-bridge -f

# Recent logs
sudo journalctl -u plex-xtream-bridge -n 100

# Errors only
sudo journalctl -u plex-xtream-bridge -p err
```

View in browser console:
- Open browser developer tools (F12)
- Check console for errors
- Check network tab for API calls
