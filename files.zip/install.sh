#!/bin/bash
# Plex Xtream Bridge - Complete Ubuntu 22.04 Installer with Web Interface

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}"
echo "============================================================"
echo "  Plex Xtream Bridge - Complete Installer"
echo "  Web Interface Version"
echo "============================================================"
echo -e "${NC}"

# Check if running as root
if [ "$EUID" -eq 0 ]; then 
    echo -e "${RED}Please do not run as root. Run as your regular user.${NC}"
    exit 1
fi

INSTALL_DIR="$HOME/plex-xtream-bridge"

echo -e "${GREEN}[1/6] Updating system packages...${NC}"
sudo apt update -qq

echo -e "${GREEN}[2/6] Installing Python 3 and dependencies...${NC}"
sudo apt install -y python3 python3-pip python3-venv curl > /dev/null 2>&1

echo -e "${GREEN}[3/6] Creating installation directory: $INSTALL_DIR${NC}"
mkdir -p "$INSTALL_DIR"
cd "$INSTALL_DIR"

echo -e "${GREEN}[4/6] Creating Python virtual environment...${NC}"
python3 -m venv venv

echo -e "${GREEN}[5/6] Installing Python packages...${NC}"
source venv/bin/activate
pip install --quiet --upgrade pip
pip install --quiet flask plexapi requests

echo -e "${GREEN}[6/6] Setting up files...${NC}"

# Check if bridge file exists
if [ ! -f "$INSTALL_DIR/plex_xtream_bridge_web.py" ]; then
    echo -e "${YELLOW}Bridge file not found in $INSTALL_DIR${NC}"
    echo -e "${YELLOW}Please copy plex_xtream_bridge_web.py to this directory${NC}"
    echo ""
    echo "Files needed:"
    echo "  - plex_xtream_bridge_web.py"
    echo ""
    echo "Then run this script again, or start manually:"
    echo "  cd $INSTALL_DIR"
    echo "  source venv/bin/activate"
    echo "  python3 plex_xtream_bridge_web.py"
    exit 1
fi

echo ""
echo -e "${GREEN}============================================================"
echo "  Installation Complete!"
echo "============================================================${NC}"
echo ""
echo "Next steps:"
echo ""
echo -e "${BLUE}Option 1: Run manually (testing)${NC}"
echo "  cd $INSTALL_DIR"
echo "  source venv/bin/activate"
echo "  python3 plex_xtream_bridge_web.py"
echo ""
echo -e "${BLUE}Option 2: Install as system service (recommended)${NC}"
echo "  sudo $0 --install-service"
echo ""
echo -e "${YELLOW}After starting, access the web interface at:${NC}"
echo "  http://$(hostname -I | awk '{print $1}'):8080/admin"
echo "  Default password: admin123"
echo ""

# Check if --install-service flag is present
if [ "$1" == "--install-service" ]; then
    echo -e "${BLUE}Installing as system service...${NC}"
    
    ACTUAL_USER="${USER}"
    
    sudo tee /etc/systemd/system/plex-xtream-bridge.service > /dev/null << EOF
[Unit]
Description=Plex to Xtream Codes API Bridge (Web Version)
After=network.target

[Service]
Type=simple
User=$ACTUAL_USER
WorkingDirectory=$INSTALL_DIR
ExecStart=$INSTALL_DIR/venv/bin/python3 $INSTALL_DIR/plex_xtream_bridge_web.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF
    
    sudo systemctl daemon-reload
    sudo systemctl enable plex-xtream-bridge
    sudo systemctl start plex-xtream-bridge
    
    sleep 2
    
    echo ""
    echo -e "${GREEN}============================================================"
    echo "  Service Installed and Started!"
    echo "============================================================${NC}"
    echo ""
    echo "Service commands:"
    echo "  sudo systemctl start plex-xtream-bridge"
    echo "  sudo systemctl stop plex-xtream-bridge"
    echo "  sudo systemctl restart plex-xtream-bridge"
    echo "  sudo systemctl status plex-xtream-bridge"
    echo "  sudo journalctl -u plex-xtream-bridge -f"
    echo ""
    echo -e "${YELLOW}Web Interface:${NC}"
    echo "  http://$(hostname -I | awk '{print $1}'):8080/admin"
    echo "  Password: admin123"
    echo ""
    echo -e "${RED}⚠️  IMPORTANT: Change the admin password after first login!${NC}"
    echo ""
fi
