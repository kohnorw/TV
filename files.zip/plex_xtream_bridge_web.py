#!/usr/bin/env python3
"""
Plex to Xtream Codes API Bridge with Web Interface
Allows Xtream UI players to access Plex library content with easy configuration
"""

from flask import Flask, jsonify, request, Response, render_template_string, redirect, url_for, session
from plexapi.server import PlexServer
import hashlib
import time
import json
import os
from datetime import datetime
from urllib.parse import quote
import secrets

app = Flask(__name__)
app.secret_key = os.getenv('SECRET_KEY', secrets.token_hex(32))

# Configuration - Update these with your settings
PLEX_URL = os.getenv('PLEX_URL', '')
PLEX_TOKEN = os.getenv('PLEX_TOKEN', '')
BRIDGE_USERNAME = os.getenv('BRIDGE_USERNAME', 'admin')
BRIDGE_PASSWORD = os.getenv('BRIDGE_PASSWORD', 'admin')
BRIDGE_HOST = os.getenv('BRIDGE_HOST', '0.0.0.0')
BRIDGE_PORT = int(os.getenv('BRIDGE_PORT', '8080'))
ADMIN_PASSWORD = os.getenv('ADMIN_PASSWORD', 'admin123')  # Web interface password

# Configuration file path
CONFIG_FILE = 'config.json'

# Initialize Plex connection
plex = None

def load_config():
    """Load configuration from file"""
    global PLEX_URL, PLEX_TOKEN, BRIDGE_USERNAME, BRIDGE_PASSWORD, ADMIN_PASSWORD
    
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, 'r') as f:
                config = json.load(f)
                PLEX_URL = config.get('plex_url', PLEX_URL)
                PLEX_TOKEN = config.get('plex_token', PLEX_TOKEN)
                BRIDGE_USERNAME = config.get('bridge_username', BRIDGE_USERNAME)
                BRIDGE_PASSWORD = config.get('bridge_password', BRIDGE_PASSWORD)
                ADMIN_PASSWORD = config.get('admin_password', ADMIN_PASSWORD)
                print("✓ Configuration loaded from file")
        except Exception as e:
            print(f"✗ Error loading config: {e}")

def save_config():
    """Save configuration to file"""
    config = {
        'plex_url': PLEX_URL,
        'plex_token': PLEX_TOKEN,
        'bridge_username': BRIDGE_USERNAME,
        'bridge_password': BRIDGE_PASSWORD,
        'admin_password': ADMIN_PASSWORD
    }
    try:
        with open(CONFIG_FILE, 'w') as f:
            json.dump(config, f, indent=2)
        print("✓ Configuration saved to file")
        return True
    except Exception as e:
        print(f"✗ Error saving config: {e}")
        return False

def connect_plex():
    """Connect to Plex server"""
    global plex
    if PLEX_URL and PLEX_TOKEN:
        try:
            plex = PlexServer(PLEX_URL, PLEX_TOKEN)
            print(f"✓ Connected to Plex Server: {plex.friendlyName}")
            return True
        except Exception as e:
            print(f"✗ Failed to connect to Plex: {e}")
            plex = None
            return False
    return False

# Load config and connect on startup
load_config()
connect_plex()

# Session storage
sessions = {}

def authenticate(username, password):
    """Authenticate user credentials"""
    return username == BRIDGE_USERNAME and password == BRIDGE_PASSWORD

def create_session(username):
    """Create a session token"""
    session_id = hashlib.md5(f"{username}{time.time()}".encode()).hexdigest()
    sessions[session_id] = {
        'username': username,
        'created_at': time.time()
    }
    return session_id

def validate_session():
    """Validate session from request parameters"""
    username = request.args.get('username')
    password = request.args.get('password')
    
    if username and password:
        return authenticate(username, password)
    return False

def get_stream_url(item, session_info=""):
    """Generate stream URL for Plex item"""
    media = item.media[0] if item.media else None
    if not media:
        return None
    
    part = media.parts[0] if media.parts else None
    if not part:
        return None
    
    base_url = PLEX_URL.rstrip('/')
    stream_url = f"{base_url}{part.key}?X-Plex-Token={PLEX_TOKEN}"
    
    return stream_url

def format_movie_for_xtream(movie, category_id=1):
    """Format Plex movie to Xtream Codes format"""
    try:
        stream_url = get_stream_url(movie)
        if not stream_url:
            return None
            
        return {
            "num": movie.ratingKey,
            "name": movie.title,
            "stream_type": "movie",
            "stream_id": movie.ratingKey,
            "stream_icon": f"{PLEX_URL}{movie.thumb}?X-Plex-Token={PLEX_TOKEN}" if movie.thumb else "",
            "rating": str(movie.rating) if movie.rating else "0",
            "rating_5based": round(float(movie.rating or 0) / 2, 1),
            "added": str(int(movie.addedAt.timestamp())) if movie.addedAt else "",
            "category_id": str(category_id),
            "container_extension": "mkv",
            "custom_sid": "",
            "direct_source": stream_url
        }
    except Exception as e:
        print(f"Error formatting movie {movie.title}: {e}")
        return None

def format_series_for_xtream(show, category_id=2):
    """Format Plex TV show to Xtream Codes format"""
    try:
        return {
            "num": show.ratingKey,
            "name": show.title,
            "series_id": show.ratingKey,
            "cover": f"{PLEX_URL}{show.thumb}?X-Plex-Token={PLEX_TOKEN}" if show.thumb else "",
            "plot": show.summary or "",
            "cast": ", ".join([actor.tag for actor in show.roles[:5]]) if show.roles else "",
            "director": show.directors[0].tag if show.directors else "",
            "genre": ", ".join([genre.tag for genre in show.genres]) if show.genres else "",
            "releaseDate": str(show.year) if show.year else "",
            "rating": str(show.rating) if show.rating else "0",
            "rating_5based": round(float(show.rating or 0) / 2, 1),
            "category_id": str(category_id),
            "last_modified": str(int(show.updatedAt.timestamp())) if show.updatedAt else ""
        }
    except Exception as e:
        print(f"Error formatting series {show.title}: {e}")
        return None

def format_episode_for_xtream(episode, series_id):
    """Format Plex episode to Xtream Codes format"""
    try:
        stream_url = get_stream_url(episode)
        if not stream_url:
            return None
            
        return {
            "id": episode.ratingKey,
            "episode_num": episode.index,
            "title": episode.title,
            "container_extension": "mkv",
            "info": {
                "tmdb_id": "",
                "releasedate": episode.originallyAvailableAt.strftime("%Y-%m-%d") if episode.originallyAvailableAt else "",
                "plot": episode.summary or "",
                "duration_secs": str(episode.duration // 1000) if episode.duration else "0",
                "duration": str(episode.duration // 60000) if episode.duration else "0",
                "rating": str(episode.rating) if episode.rating else "0",
                "season": episode.seasonNumber,
                "cover_big": f"{PLEX_URL}{episode.thumb}?X-Plex-Token={PLEX_TOKEN}" if episode.thumb else ""
            },
            "direct_source": stream_url
        }
    except Exception as e:
        print(f"Error formatting episode {episode.title}: {e}")
        return None

# Web Interface Templates

DASHBOARD_HTML = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Plex Xtream Bridge - Dashboard</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
        }
        
        .header {
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            margin-bottom: 20px;
        }
        
        .header h1 {
            color: #333;
            margin-bottom: 10px;
        }
        
        .header p {
            color: #666;
        }
        
        .status-card {
            background: white;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        
        .status-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }
        
        .status-item {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 10px;
            border-left: 4px solid #667eea;
        }
        
        .status-item h3 {
            color: #333;
            font-size: 14px;
            margin-bottom: 8px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .status-item p {
            color: #666;
            font-size: 18px;
            font-weight: 600;
        }
        
        .status-badge {
            display: inline-block;
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 14px;
            font-weight: 600;
        }
        
        .status-connected {
            background: #d4edda;
            color: #155724;
        }
        
        .status-disconnected {
            background: #f8d7da;
            color: #721c24;
        }
        
        .button {
            display: inline-block;
            padding: 12px 24px;
            background: #667eea;
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-weight: 600;
            border: none;
            cursor: pointer;
            transition: background 0.3s;
        }
        
        .button:hover {
            background: #5568d3;
        }
        
        .button-secondary {
            background: #6c757d;
        }
        
        .button-secondary:hover {
            background: #5a6268;
        }
        
        .button-danger {
            background: #dc3545;
        }
        
        .button-danger:hover {
            background: #c82333;
        }
        
        .library-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 15px;
            margin-top: 20px;
        }
        
        .library-item {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
        }
        
        .library-item h4 {
            color: #333;
            margin-bottom: 10px;
        }
        
        .library-count {
            font-size: 32px;
            font-weight: bold;
            color: #667eea;
        }
        
        .config-section {
            background: white;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        
        .config-section h2 {
            color: #333;
            margin-bottom: 20px;
        }
        
        .info-box {
            background: #e7f3ff;
            border-left: 4px solid #2196F3;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        
        .code-box {
            background: #2d2d2d;
            color: #f8f8f2;
            padding: 15px;
            border-radius: 8px;
            font-family: 'Courier New', monospace;
            overflow-x: auto;
        }
        
        .action-buttons {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🎬 Plex Xtream Bridge</h1>
            <p>Connect your Plex library to any Xtream UI player</p>
        </div>
        
        <div class="status-card">
            <h2 style="margin-bottom: 20px;">System Status</h2>
            <div class="status-grid">
                <div class="status-item">
                    <h3>Plex Server</h3>
                    <p>
                        {% if plex_connected %}
                        <span class="status-badge status-connected">✓ Connected</span>
                        {% else %}
                        <span class="status-badge status-disconnected">✗ Disconnected</span>
                        {% endif %}
                    </p>
                </div>
                
                <div class="status-item">
                    <h3>Server Name</h3>
                    <p>{{ server_name }}</p>
                </div>
                
                <div class="status-item">
                    <h3>Bridge URL</h3>
                    <p style="font-size: 14px;">{{ bridge_url }}</p>
                </div>
                
                <div class="status-item">
                    <h3>Active Users</h3>
                    <p>{{ active_sessions }} connected</p>
                </div>
            </div>
            
            {% if plex_connected and libraries %}
            <h3 style="margin-top: 20px; margin-bottom: 10px;">Your Libraries</h3>
            <div class="library-grid">
                {% for lib in libraries %}
                <div class="library-item">
                    <h4>{{ lib.name }}</h4>
                    <div class="library-count">{{ lib.count }}</div>
                    <p style="color: #666; font-size: 12px; margin-top: 5px;">{{ lib.type }}</p>
                </div>
                {% endfor %}
            </div>
            {% endif %}
        </div>
        
        <div class="config-section">
            <h2>🔧 Configuration</h2>
            
            {% if not plex_connected %}
            <div class="info-box">
                <strong>⚠️ Not connected to Plex</strong><br>
                Please configure your Plex server connection below.
            </div>
            {% endif %}
            
            <div class="action-buttons">
                <a href="/admin/settings" class="button">⚙️ Settings</a>
                <a href="/admin/test" class="button button-secondary">🧪 Test Connection</a>
                <a href="/admin/logs" class="button button-secondary">📋 View Logs</a>
                <a href="/admin/logout" class="button button-danger">🚪 Logout</a>
            </div>
        </div>
        
        <div class="config-section">
            <h2>📱 Player Configuration</h2>
            <div class="info-box">
                Use these settings in your Xtream UI player (TiviMate, IPTV Smarters, etc.)
            </div>
            
            <div class="status-grid">
                <div class="status-item">
                    <h3>Server URL</h3>
                    <p style="font-size: 14px; word-break: break-all;">{{ bridge_url }}</p>
                </div>
                
                <div class="status-item">
                    <h3>Username</h3>
                    <p>{{ bridge_username }}</p>
                </div>
                
                <div class="status-item">
                    <h3>Password</h3>
                    <p>{{ bridge_password }}</p>
                </div>
            </div>
            
            <h3 style="margin-top: 20px; margin-bottom: 10px;">Test API Endpoint</h3>
            <div class="code-box">
{{ bridge_url }}/player_api.php?username={{ bridge_username }}&password={{ bridge_password }}
            </div>
        </div>
    </div>
</body>
</html>
"""

SETTINGS_HTML = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Settings - Plex Xtream Bridge</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        
        .container {
            max-width: 800px;
            margin: 0 auto;
        }
        
        .card {
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            margin-bottom: 20px;
        }
        
        .card h1 {
            color: #333;
            margin-bottom: 10px;
        }
        
        .card h2 {
            color: #333;
            margin-bottom: 20px;
            font-size: 20px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            color: #333;
            font-weight: 600;
            margin-bottom: 8px;
        }
        
        .form-group input {
            width: 100%;
            padding: 12px;
            border: 2px solid #e1e4e8;
            border-radius: 8px;
            font-size: 14px;
            transition: border-color 0.3s;
        }
        
        .form-group input:focus {
            outline: none;
            border-color: #667eea;
        }
        
        .form-group small {
            display: block;
            color: #666;
            margin-top: 5px;
            font-size: 12px;
        }
        
        .button {
            display: inline-block;
            padding: 12px 24px;
            background: #667eea;
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-weight: 600;
            border: none;
            cursor: pointer;
            transition: background 0.3s;
        }
        
        .button:hover {
            background: #5568d3;
        }
        
        .button-secondary {
            background: #6c757d;
        }
        
        .button-secondary:hover {
            background: #5a6268;
        }
        
        .button-group {
            display: flex;
            gap: 10px;
            margin-top: 20px;
        }
        
        .alert {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        
        .alert-success {
            background: #d4edda;
            color: #155724;
            border-left: 4px solid #28a745;
        }
        
        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border-left: 4px solid #dc3545;
        }
        
        .alert-info {
            background: #d1ecf1;
            color: #0c5460;
            border-left: 4px solid #17a2b8;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <h1>⚙️ Settings</h1>
            <p style="color: #666; margin-bottom: 20px;">Configure your Plex connection and bridge credentials</p>
            
            <a href="/admin" class="button button-secondary" style="margin-bottom: 20px;">← Back to Dashboard</a>
        </div>
        
        {% if message %}
        <div class="alert {% if error %}alert-error{% else %}alert-success{% endif %}">
            {{ message }}
        </div>
        {% endif %}
        
        <form method="POST" action="/admin/settings">
            <div class="card">
                <h2>Plex Server Configuration</h2>
                
                <div class="form-group">
                    <label for="plex_url">Plex Server URL</label>
                    <input type="text" id="plex_url" name="plex_url" value="{{ plex_url }}" placeholder="http://192.168.1.100:32400" required>
                    <small>The URL of your Plex Media Server (include http:// or https://)</small>
                </div>
                
                <div class="form-group">
                    <label for="plex_token">Plex Token</label>
                    <input type="text" id="plex_token" name="plex_token" value="{{ plex_token }}" placeholder="Your Plex authentication token" required>
                    <small>Get from Plex Web: Play media → Get Info → View XML → Copy X-Plex-Token</small>
                </div>
            </div>
            
            <div class="card">
                <h2>Bridge Credentials</h2>
                
                <div class="alert alert-info">
                    These credentials are used by your Xtream UI player to connect to the bridge.
                </div>
                
                <div class="form-group">
                    <label for="bridge_username">Bridge Username</label>
                    <input type="text" id="bridge_username" name="bridge_username" value="{{ bridge_username }}" required>
                    <small>Username for Xtream UI player authentication</small>
                </div>
                
                <div class="form-group">
                    <label for="bridge_password">Bridge Password</label>
                    <input type="text" id="bridge_password" name="bridge_password" value="{{ bridge_password }}" required>
                    <small>Password for Xtream UI player authentication</small>
                </div>
            </div>
            
            <div class="card">
                <h2>Admin Panel Security</h2>
                
                <div class="form-group">
                    <label for="admin_password">Admin Panel Password</label>
                    <input type="password" id="admin_password" name="admin_password" value="{{ admin_password }}" required>
                    <small>Password to access this admin panel</small>
                </div>
            </div>
            
            <div class="card">
                <div class="button-group">
                    <button type="submit" class="button">💾 Save Settings</button>
                    <a href="/admin" class="button button-secondary">Cancel</a>
                </div>
            </div>
        </form>
    </div>
</body>
</html>
"""

LOGIN_HTML = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Plex Xtream Bridge</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        .login-card {
            background: white;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            max-width: 400px;
            width: 100%;
        }
        
        .login-card h1 {
            color: #333;
            margin-bottom: 10px;
            text-align: center;
        }
        
        .login-card p {
            color: #666;
            text-align: center;
            margin-bottom: 30px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            color: #333;
            font-weight: 600;
            margin-bottom: 8px;
        }
        
        .form-group input {
            width: 100%;
            padding: 12px;
            border: 2px solid #e1e4e8;
            border-radius: 8px;
            font-size: 14px;
        }
        
        .form-group input:focus {
            outline: none;
            border-color: #667eea;
        }
        
        .button {
            width: 100%;
            padding: 12px;
            background: #667eea;
            color: white;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            font-size: 16px;
        }
        
        .button:hover {
            background: #5568d3;
        }
        
        .alert-error {
            background: #f8d7da;
            color: #721c24;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
            border-left: 4px solid #dc3545;
        }
    </style>
</head>
<body>
    <div class="login-card">
        <h1>🔐 Admin Login</h1>
        <p>Plex Xtream Bridge</p>
        
        {% if error %}
        <div class="alert-error">
            {{ error }}
        </div>
        {% endif %}
        
        <form method="POST" action="/admin/login">
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required autofocus>
            </div>
            
            <button type="submit" class="button">Login</button>
        </form>
    </div>
</body>
</html>
"""

# Web Interface Routes

@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    """Admin login page"""
    if request.method == 'POST':
        password = request.form.get('password')
        if password == ADMIN_PASSWORD:
            session['admin_logged_in'] = True
            return redirect(url_for('admin_dashboard'))
        else:
            return render_template_string(LOGIN_HTML, error="Invalid password")
    
    return render_template_string(LOGIN_HTML)

@app.route('/admin/logout')
def admin_logout():
    """Logout"""
    session.pop('admin_logged_in', None)
    return redirect(url_for('admin_login'))

def require_admin_login(f):
    """Decorator to require admin login"""
    def decorated_function(*args, **kwargs):
        if not session.get('admin_logged_in'):
            return redirect(url_for('admin_login'))
        return f(*args, **kwargs)
    decorated_function.__name__ = f.__name__
    return decorated_function

@app.route('/admin')
@require_admin_login
def admin_dashboard():
    """Admin dashboard"""
    libraries = []
    server_name = "Not connected"
    
    if plex:
        server_name = plex.friendlyName
        for section in plex.library.sections():
            libraries.append({
                'name': section.title,
                'type': section.type.title(),
                'count': len(section.all())
            })
    
    # Get server IP
    import socket
    hostname = socket.gethostname()
    local_ip = socket.gethostbyname(hostname)
    bridge_url = f"http://{local_ip}:{BRIDGE_PORT}"
    
    return render_template_string(DASHBOARD_HTML,
        plex_connected=plex is not None,
        server_name=server_name,
        bridge_url=bridge_url,
        bridge_username=BRIDGE_USERNAME,
        bridge_password=BRIDGE_PASSWORD,
        active_sessions=len(sessions),
        libraries=libraries
    )

@app.route('/admin/settings', methods=['GET', 'POST'])
@require_admin_login
def admin_settings():
    """Settings page"""
    global PLEX_URL, PLEX_TOKEN, BRIDGE_USERNAME, BRIDGE_PASSWORD, ADMIN_PASSWORD
    
    message = None
    error = False
    
    if request.method == 'POST':
        PLEX_URL = request.form.get('plex_url')
        PLEX_TOKEN = request.form.get('plex_token')
        BRIDGE_USERNAME = request.form.get('bridge_username')
        BRIDGE_PASSWORD = request.form.get('bridge_password')
        ADMIN_PASSWORD = request.form.get('admin_password')
        
        if save_config():
            if connect_plex():
                message = "✓ Settings saved and connected to Plex successfully!"
            else:
                message = "⚠️ Settings saved but failed to connect to Plex. Check your URL and token."
                error = True
        else:
            message = "✗ Failed to save settings"
            error = True
    
    return render_template_string(SETTINGS_HTML,
        plex_url=PLEX_URL,
        plex_token=PLEX_TOKEN,
        bridge_username=BRIDGE_USERNAME,
        bridge_password=BRIDGE_PASSWORD,
        admin_password=ADMIN_PASSWORD,
        message=message,
        error=error
    )

@app.route('/admin/test')
@require_admin_login
def admin_test():
    """Test Plex connection"""
    if connect_plex():
        return jsonify({
            "success": True,
            "message": f"Successfully connected to {plex.friendlyName}",
            "version": plex.version,
            "libraries": [s.title for s in plex.library.sections()]
        })
    else:
        return jsonify({
            "success": False,
            "message": "Failed to connect to Plex. Check your URL and token."
        }), 500

# Xtream Codes API Endpoints (keeping all previous API code)

@app.route('/player_api.php')
def player_api():
    """Main Xtream Codes API endpoint"""
    if not plex:
        return jsonify({"error": "Plex server not connected"}), 500
    
    action = request.args.get('action')
    
    if not validate_session():
        return jsonify({
            "user_info": {"auth": 0, "status": "Expired", "message": "Invalid credentials"}
        }), 401
    
    # Authentication endpoint
    if action is None and request.args.get('username') and request.args.get('password'):
        server_info = {
            "url": PLEX_URL,
            "port": BRIDGE_PORT,
            "https_port": "",
            "server_protocol": "http",
            "rtmp_port": "",
            "timezone": "UTC",
            "timestamp_now": int(time.time()),
            "time_now": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
        
        user_info = {
            "username": request.args.get('username'),
            "password": request.args.get('password'),
            "message": "Welcome to Plex Bridge",
            "auth": 1,
            "status": "Active",
            "exp_date": "9999999999",
            "is_trial": "0",
            "active_cons": "1",
            "created_at": str(int(time.time())),
            "max_connections": "5",
            "allowed_output_formats": ["m3u8", "ts"]
        }
        
        return jsonify({
            "user_info": user_info,
            "server_info": server_info
        })
    
    # Get VOD categories
    elif action == 'get_vod_categories':
        categories = []
        for section in plex.library.sections():
            if section.type == 'movie':
                categories.append({
                    "category_id": section.key,
                    "category_name": section.title,
                    "parent_id": 0
                })
        return jsonify(categories)
    
    # Get VOD streams (movies)
    elif action == 'get_vod_streams':
        category_id = request.args.get('category_id')
        movies = []
        
        if category_id:
            try:
                section = plex.library.sectionByID(int(category_id))
                for movie in section.all():
                    formatted = format_movie_for_xtream(movie, category_id)
                    if formatted:
                        movies.append(formatted)
            except Exception as e:
                print(f"Error getting movies: {e}")
        else:
            for section in plex.library.sections():
                if section.type == 'movie':
                    for movie in section.all():
                        formatted = format_movie_for_xtream(movie, section.key)
                        if formatted:
                            movies.append(formatted)
        
        return jsonify(movies)
    
    # Get VOD info
    elif action == 'get_vod_info':
        vod_id = request.args.get('vod_id')
        if not vod_id:
            return jsonify({"error": "Missing vod_id"}), 400
        
        try:
            movie = plex.fetchItem(int(vod_id))
            stream_url = get_stream_url(movie)
            
            info = {
                "info": {
                    "tmdb_id": "",
                    "name": movie.title,
                    "o_name": movie.originalTitle or movie.title,
                    "cover_big": f"{PLEX_URL}{movie.art}?X-Plex-Token={PLEX_TOKEN}" if movie.art else "",
                    "movie_image": f"{PLEX_URL}{movie.thumb}?X-Plex-Token={PLEX_TOKEN}" if movie.thumb else "",
                    "releasedate": str(movie.year) if movie.year else "",
                    "youtube_trailer": "",
                    "director": ", ".join([d.tag for d in movie.directors]) if movie.directors else "",
                    "actors": ", ".join([a.tag for a in movie.roles[:10]]) if movie.roles else "",
                    "cast": ", ".join([a.tag for a in movie.roles[:10]]) if movie.roles else "",
                    "description": movie.summary or "",
                    "plot": movie.summary or "",
                    "age": movie.contentRating or "",
                    "rating": str(movie.rating) if movie.rating else "0",
                    "rating_5based": round(float(movie.rating or 0) / 2, 1),
                    "duration_secs": str(movie.duration // 1000) if movie.duration else "0",
                    "duration": str(movie.duration // 60000) if movie.duration else "0",
                    "genre": ", ".join([g.tag for g in movie.genres]) if movie.genres else "",
                    "backdrop_path": [f"{PLEX_URL}{movie.art}?X-Plex-Token={PLEX_TOKEN}"] if movie.art else []
                },
                "movie_data": {
                    "stream_id": movie.ratingKey,
                    "name": movie.title,
                    "container_extension": "mkv",
                    "custom_sid": "",
                    "direct_source": stream_url
                }
            }
            return jsonify(info)
        except Exception as e:
            return jsonify({"error": str(e)}), 404
    
    # Get series categories
    elif action == 'get_series_categories':
        categories = []
        for section in plex.library.sections():
            if section.type == 'show':
                categories.append({
                    "category_id": section.key,
                    "category_name": section.title,
                    "parent_id": 0
                })
        return jsonify(categories)
    
    # Get series
    elif action == 'get_series':
        category_id = request.args.get('category_id')
        series_list = []
        
        if category_id:
            try:
                section = plex.library.sectionByID(int(category_id))
                for show in section.all():
                    formatted = format_series_for_xtream(show, category_id)
                    if formatted:
                        series_list.append(formatted)
            except Exception as e:
                print(f"Error getting series: {e}")
        else:
            for section in plex.library.sections():
                if section.type == 'show':
                    for show in section.all():
                        formatted = format_series_for_xtream(show, section.key)
                        if formatted:
                            series_list.append(formatted)
        
        return jsonify(series_list)
    
    # Get series info
    elif action == 'get_series_info':
        series_id = request.args.get('series_id')
        if not series_id:
            return jsonify({"error": "Missing series_id"}), 400
        
        try:
            show = plex.fetchItem(int(series_id))
            
            seasons = {}
            episodes_data = {}
            
            for season in show.seasons():
                season_num = season.seasonNumber
                if season_num is None:
                    continue
                    
                seasons[season_num] = {
                    "air_date": str(season.year) if hasattr(season, 'year') and season.year else "",
                    "episode_count": len(season.episodes()),
                    "id": season.ratingKey,
                    "name": season.title,
                    "overview": season.summary or "",
                    "season_number": season_num,
                    "cover": f"{PLEX_URL}{season.thumb}?X-Plex-Token={PLEX_TOKEN}" if season.thumb else "",
                    "cover_big": f"{PLEX_URL}{season.art}?X-Plex-Token={PLEX_TOKEN}" if hasattr(season, 'art') and season.art else ""
                }
                
                episodes = []
                for episode in season.episodes():
                    formatted_episode = format_episode_for_xtream(episode, series_id)
                    if formatted_episode:
                        episodes.append(formatted_episode)
                
                if episodes:
                    episodes_data[season_num] = episodes
            
            info = {
                "seasons": list(seasons.values()),
                "info": {
                    "name": show.title,
                    "cover": f"{PLEX_URL}{show.thumb}?X-Plex-Token={PLEX_TOKEN}" if show.thumb else "",
                    "plot": show.summary or "",
                    "cast": ", ".join([actor.tag for actor in show.roles[:10]]) if show.roles else "",
                    "director": ", ".join([d.tag for d in show.directors]) if show.directors else "",
                    "genre": ", ".join([g.tag for g in show.genres]) if show.genres else "",
                    "releaseDate": str(show.year) if show.year else "",
                    "rating": str(show.rating) if show.rating else "0",
                    "rating_5based": round(float(show.rating or 0) / 2, 1),
                    "backdrop_path": [f"{PLEX_URL}{show.art}?X-Plex-Token={PLEX_TOKEN}"] if show.art else [],
                    "youtube_trailer": "",
                    "episode_run_time": "",
                    "category_id": "2"
                },
                "episodes": episodes_data
            }
            
            return jsonify(info)
        except Exception as e:
            return jsonify({"error": str(e)}), 404
    
    return jsonify({"error": "Unknown action"}), 400

@app.route('/movie/<username>/<password>/<stream_id>.mkv')
@app.route('/movie/<username>/<password>/<stream_id>.mp4')
def stream_movie(username, password, stream_id):
    """Stream a movie"""
    if not authenticate(username, password):
        return "Unauthorized", 401
    
    try:
        movie = plex.fetchItem(int(stream_id))
        stream_url = get_stream_url(movie)
        if stream_url:
            return Response(
                status=302,
                headers={'Location': stream_url}
            )
        return "Stream not found", 404
    except Exception as e:
        return str(e), 404

@app.route('/series/<username>/<password>/<stream_id>.mkv')
@app.route('/series/<username>/<password>/<stream_id>.mp4')
def stream_episode(username, password, stream_id):
    """Stream a TV episode"""
    if not authenticate(username, password):
        return "Unauthorized", 401
    
    try:
        episode = plex.fetchItem(int(stream_id))
        stream_url = get_stream_url(episode)
        if stream_url:
            return Response(
                status=302,
                headers={'Location': stream_url}
            )
        return "Stream not found", 404
    except Exception as e:
        return str(e), 404

@app.route('/')
def index():
    """Root endpoint - redirect to admin"""
    return redirect(url_for('admin_dashboard'))

if __name__ == '__main__':
    print("=" * 60)
    print("Plex to Xtream Codes API Bridge with Web Interface")
    print("=" * 60)
    print(f"Web Interface: http://{BRIDGE_HOST}:{BRIDGE_PORT}/admin")
    print(f"Default Admin Password: {ADMIN_PASSWORD}")
    print(f"API Endpoint: http://{BRIDGE_HOST}:{BRIDGE_PORT}/player_api.php")
    print(f"Bridge Username: {BRIDGE_USERNAME}")
    print(f"Bridge Password: {BRIDGE_PASSWORD}")
    print("=" * 60)
    print("\n⚠️  IMPORTANT: Change the admin password after first login!")
    print("=" * 60)
    
    app.run(host=BRIDGE_HOST, port=BRIDGE_PORT, debug=False, threaded=True)
