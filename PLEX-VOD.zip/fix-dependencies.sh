#!/bin/bash
# Quick fix for missing dependencies

echo "Installing Python dependencies..."

# Check if running in virtual environment
if [ -d "venv" ]; then
    echo "Virtual environment found, activating..."
    source venv/bin/activate
    pip install --break-system-packages flask==3.0.0 plexapi==4.15.7 requests==2.31.0 cryptography==41.0.7
else
    echo "No virtual environment found, installing system-wide..."
    pip3 install --break-system-packages flask==3.0.0 plexapi==4.15.7 requests==2.31.0 cryptography==41.0.7
fi

echo ""
echo "✓ Dependencies installed!"
echo ""
echo "Now start the bridge:"
echo "  python3 plex_xtream_bridge_web.py"
