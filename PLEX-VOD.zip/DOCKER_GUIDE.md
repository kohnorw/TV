# 🐳 Docker Installation Guide

Complete guide to running Plex Xtream Bridge in Docker.

## 📦 Quick Start

### **1. Download Files**

You need these files in the same directory:
```
plex-xtream-bridge/
├── Dockerfile
├── docker-compose.yml
├── .dockerignore
├── requirements.txt
└── plex_xtream_bridge_web.py
```

### **2. Build and Run**

```bash
# Build the image
docker-compose build

# Start the container
docker-compose up -d

# Check logs
docker-compose logs -f
```

### **3. Access**

Open: `http://YOUR_SERVER_IP:8080/admin`

Default password: `admin123` (you'll be forced to change it)

## 🚀 Installation Methods

### **Method 1: Docker Compose (Recommended)**

```bash
# Create directory
mkdir plex-xtream-bridge
cd plex-xtream-bridge

# Place all files here
# Then:

docker-compose up -d
```

### **Method 2: Docker Build**

```bash
# Build image
docker build -t plex-xtream-bridge .

# Run container
docker run -d \
  --name plex-xtream-bridge \
  -p 8080:8080 \
  -v $(pwd)/data:/app/data \
  --restart unless-stopped \
  plex-xtream-bridge
```

### **Method 3: Pre-built Image (Future)**

```bash
# Pull from registry (when available)
docker pull ghcr.io/yourusername/plex-xtream-bridge:latest

# Run
docker run -d \
  --name plex-xtream-bridge \
  -p 8080:8080 \
  -v ./data:/app/data \
  --restart unless-stopped \
  ghcr.io/yourusername/plex-xtream-bridge:latest
```

## ⚙️ Configuration

### **Via Web Interface (Recommended):**

1. Go to `http://YOUR_IP:8080/admin`
2. Login with `admin123`
3. Set new passwords
4. Go to Settings
5. Configure:
   - Plex URL: `http://your-plex-ip:32400`
   - Plex Token: Your token
   - TMDb API Key (optional)

### **Via Environment Variables:**

Edit `docker-compose.yml`:

```yaml
environment:
  - PLEX_URL=http://192.168.1.100:32400
  - PLEX_TOKEN=your-token-here
  - BRIDGE_USERNAME=myuser
  - BRIDGE_PASSWORD=mypassword
  - ADMIN_PASSWORD=admin-password
  - TMDB_API_KEY=your-tmdb-key
```

Then restart:
```bash
docker-compose down
docker-compose up -d
```

## 📁 Data Persistence

Configuration is stored in `./data` directory:

```
data/
├── config.json          # Main configuration
├── categories.json      # Custom categories
└── .encryption_key      # Encryption key
```

**Backup this directory!** It contains all your settings.

## 🔧 Docker Commands

### **Start/Stop:**
```bash
docker-compose up -d        # Start
docker-compose down         # Stop
docker-compose restart      # Restart
```

### **Logs:**
```bash
docker-compose logs -f                    # Follow logs
docker-compose logs --tail=100            # Last 100 lines
docker-compose logs plex-xtream-bridge    # Specific service
```

### **Update:**
```bash
# Stop container
docker-compose down

# Pull new code
git pull  # or download new files

# Rebuild
docker-compose build --no-cache

# Start
docker-compose up -d
```

### **Shell Access:**
```bash
docker-compose exec plex-xtream-bridge /bin/bash
```

### **Health Check:**
```bash
docker-compose ps
# Should show "healthy"
```

## 🌐 Network Configuration

### **Default (Bridge Network):**
Container runs on its own network, accessible via host port 8080.

### **Host Network Mode:**

For better performance, use host network:

```yaml
services:
  plex-xtream-bridge:
    network_mode: host
    # Remove ports: section when using host mode
```

Then restart:
```bash
docker-compose down
docker-compose up -d
```

### **With Plex in Docker:**

If Plex also runs in Docker:

```yaml
services:
  plex-xtream-bridge:
    depends_on:
      - plex
    environment:
      - PLEX_URL=http://plex:32400
  
  plex:
    image: plexinc/pms-docker
    # ... plex config
```

## 🔒 Security

### **1. Change Default Passwords:**
First login forces password change ✅

### **2. Use Strong Passwords:**
- Admin: 8+ characters
- Bridge: 8+ characters

### **3. Restrict Access:**

**Option A: Firewall**
```bash
# Only allow from local network
sudo ufw allow from 192.168.1.0/24 to any port 8080
```

**Option B: Reverse Proxy**

Use nginx/Caddy with authentication:
```nginx
location /admin {
    auth_basic "Restricted";
    auth_basic_user_file /etc/nginx/.htpasswd;
    proxy_pass http://localhost:8080;
}
```

## 📊 Resource Usage

### **Typical Usage:**
- **CPU:** 1-5% idle, 10-20% when streaming
- **RAM:** 100-200 MB
- **Disk:** <100 MB

### **Limits (Optional):**

Add to `docker-compose.yml`:
```yaml
services:
  plex-xtream-bridge:
    deploy:
      resources:
        limits:
          cpus: '0.5'
          memory: 512M
        reservations:
          memory: 128M
```

## 🐛 Troubleshooting

### **Container Won't Start:**

```bash
# Check logs
docker-compose logs

# Common issues:
# 1. Port 8080 in use
sudo lsof -i :8080

# 2. Permission issues
sudo chown -R 1000:1000 ./data
```

### **Can't Connect to Plex:**

```bash
# Test from inside container
docker-compose exec plex-xtream-bridge curl http://YOUR_PLEX_IP:32400

# Should return XML
```

### **Config Not Persisting:**

```bash
# Check volume mount
docker-compose exec plex-xtream-bridge ls -la /app/data

# Should show config.json
```

### **Bridge Returns Errors:**

```bash
# Check container health
docker-compose ps

# View detailed logs
docker-compose logs --tail=200

# Restart container
docker-compose restart
```

## 🔄 Upgrade Process

### **1. Backup Data:**
```bash
cp -r data data.backup
```

### **2. Stop Container:**
```bash
docker-compose down
```

### **3. Update Files:**
```bash
# Download new plex_xtream_bridge_web.py
# Or: git pull
```

### **4. Rebuild:**
```bash
docker-compose build --no-cache
```

### **5. Start:**
```bash
docker-compose up -d
```

### **6. Verify:**
```bash
docker-compose logs -f
# Check for errors
```

## 🌍 Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `PLEX_URL` | - | Plex server URL |
| `PLEX_TOKEN` | - | Plex authentication token |
| `BRIDGE_USERNAME` | `admin` | Player username |
| `BRIDGE_PASSWORD` | `admin` | Player password |
| `ADMIN_PASSWORD` | `admin123` | Admin panel password |
| `TMDB_API_KEY` | - | TMDb API key (optional) |
| `PORT` | `8080` | Server port |

## 📝 docker-compose.yml Examples

### **Basic:**
```yaml
version: '3.8'
services:
  plex-xtream-bridge:
    build: .
    container_name: plex-xtream-bridge
    restart: unless-stopped
    ports:
      - "8080:8080"
    volumes:
      - ./data:/app/data
```

### **With Environment Variables:**
```yaml
version: '3.8'
services:
  plex-xtream-bridge:
    build: .
    container_name: plex-xtream-bridge
    restart: unless-stopped
    ports:
      - "8080:8080"
    volumes:
      - ./data:/app/data
    environment:
      - PLEX_URL=http://192.168.1.100:32400
      - PLEX_TOKEN=aBcDeFgHiJkLmNoPqRsTuVwXyZ
      - BRIDGE_USERNAME=myuser
      - BRIDGE_PASSWORD=securepass123
```

### **With Plex in Docker:**
```yaml
version: '3.8'
services:
  plex:
    image: plexinc/pms-docker
    container_name: plex
    restart: unless-stopped
    ports:
      - "32400:32400"
    volumes:
      - ./plex-config:/config
      - ./media:/media

  plex-xtream-bridge:
    build: .
    container_name: plex-xtream-bridge
    restart: unless-stopped
    ports:
      - "8080:8080"
    volumes:
      - ./data:/app/data
    environment:
      - PLEX_URL=http://plex:32400
    depends_on:
      - plex
```

## 🎯 Best Practices

1. **Use volumes** for data persistence
2. **Set resource limits** to prevent runaway
3. **Use restart policies** for reliability
4. **Enable health checks** for monitoring
5. **Backup data directory** regularly
6. **Use environment files** for secrets
7. **Run as non-root** (built into image)
8. **Keep images updated** for security

## 📋 Complete Setup Checklist

- [ ] Download all required files
- [ ] Create `data` directory
- [ ] Build Docker image
- [ ] Start container
- [ ] Access web interface
- [ ] Change default passwords
- [ ] Configure Plex URL and token
- [ ] Add TMDb API key (optional)
- [ ] Test movie playback
- [ ] Test TV show playback
- [ ] Configure player app
- [ ] Backup data directory
- [ ] Set up monitoring

## 🎉 Summary

Docker deployment offers:
- ✅ **Easy installation** - One command
- ✅ **Isolation** - No system dependencies
- ✅ **Portability** - Run anywhere
- ✅ **Updates** - Simple rebuild
- ✅ **Rollback** - Easy version control
- ✅ **Resource limits** - Prevent issues
- ✅ **Health checks** - Auto-restart

Your bridge is now containerized! 🐳
