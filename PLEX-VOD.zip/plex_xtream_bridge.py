#!/usr/bin/env python3
"""
Plex to Xtream Codes API Bridge
Allows Xtream UI players to access Plex library content
"""

from flask import Flask, jsonify, request, Response, send_file
from plexapi.server import PlexServer
import hashlib
import time
import json
import os
from datetime import datetime
from urllib.parse import quote

app = Flask(__name__)

# Configuration - Update these with your settings
PLEX_URL = os.getenv('PLEX_URL', 'http://localhost:32400')
PLEX_TOKEN = os.getenv('PLEX_TOKEN', 'YOUR_PLEX_TOKEN')
BRIDGE_USERNAME = os.getenv('BRIDGE_USERNAME', 'admin')
BRIDGE_PASSWORD = os.getenv('BRIDGE_PASSWORD', 'admin')
BRIDGE_HOST = os.getenv('BRIDGE_HOST', '0.0.0.0')
BRIDGE_PORT = int(os.getenv('BRIDGE_PORT', '8080'))

# Initialize Plex connection
try:
    plex = PlexServer(PLEX_URL, PLEX_TOKEN)
    print(f"✓ Connected to Plex Server: {plex.friendlyName}")
except Exception as e:
    print(f"✗ Failed to connect to Plex: {e}")
    plex = None

# Session storage (in production, use Redis or similar)
sessions = {}

def authenticate(username, password):
    """Authenticate user credentials"""
    return username == BRIDGE_USERNAME and password == BRIDGE_PASSWORD

def create_session(username):
    """Create a session token"""
    session_id = hashlib.md5(f"{username}{time.time()}".encode()).hexdigest()
    sessions[session_id] = {
        'username': username,
        'created_at': time.time()
    }
    return session_id

def validate_session():
    """Validate session from request parameters"""
    username = request.args.get('username')
    password = request.args.get('password')
    
    if username and password:
        return authenticate(username, password)
    return False

def get_stream_url(item, session_info=""):
    """Generate stream URL for Plex item"""
    # Get the media part URL
    media = item.media[0] if item.media else None
    if not media:
        return None
    
    part = media.parts[0] if media.parts else None
    if not part:
        return None
    
    # Build the stream URL
    base_url = PLEX_URL.rstrip('/')
    stream_url = f"{base_url}{part.key}?X-Plex-Token={PLEX_TOKEN}"
    
    return stream_url

def format_movie_for_xtream(movie, category_id=1):
    """Format Plex movie to Xtream Codes format"""
    try:
        stream_url = get_stream_url(movie)
        if not stream_url:
            return None
            
        return {
            "num": movie.ratingKey,
            "name": movie.title,
            "stream_type": "movie",
            "stream_id": movie.ratingKey,
            "stream_icon": f"{PLEX_URL}{movie.thumb}?X-Plex-Token={PLEX_TOKEN}" if movie.thumb else "",
            "rating": str(movie.rating) if movie.rating else "0",
            "rating_5based": round(float(movie.rating or 0) / 2, 1),
            "added": str(int(movie.addedAt.timestamp())) if movie.addedAt else "",
            "category_id": str(category_id),
            "container_extension": "mkv",
            "custom_sid": "",
            "direct_source": stream_url
        }
    except Exception as e:
        print(f"Error formatting movie {movie.title}: {e}")
        return None

def format_series_for_xtream(show, category_id=2):
    """Format Plex TV show to Xtream Codes format"""
    try:
        return {
            "num": show.ratingKey,
            "name": show.title,
            "series_id": show.ratingKey,
            "cover": f"{PLEX_URL}{show.thumb}?X-Plex-Token={PLEX_TOKEN}" if show.thumb else "",
            "plot": show.summary or "",
            "cast": ", ".join([actor.tag for actor in show.roles[:5]]) if show.roles else "",
            "director": show.directors[0].tag if show.directors else "",
            "genre": ", ".join([genre.tag for genre in show.genres]) if show.genres else "",
            "releaseDate": str(show.year) if show.year else "",
            "rating": str(show.rating) if show.rating else "0",
            "rating_5based": round(float(show.rating or 0) / 2, 1),
            "category_id": str(category_id),
            "last_modified": str(int(show.updatedAt.timestamp())) if show.updatedAt else ""
        }
    except Exception as e:
        print(f"Error formatting series {show.title}: {e}")
        return None

def format_episode_for_xtream(episode, series_id):
    """Format Plex episode to Xtream Codes format"""
    try:
        stream_url = get_stream_url(episode)
        if not stream_url:
            return None
            
        return {
            "id": episode.ratingKey,
            "episode_num": episode.index,
            "title": episode.title,
            "container_extension": "mkv",
            "info": {
                "tmdb_id": "",
                "releasedate": episode.originallyAvailableAt.strftime("%Y-%m-%d") if episode.originallyAvailableAt else "",
                "plot": episode.summary or "",
                "duration_secs": str(episode.duration // 1000) if episode.duration else "0",
                "duration": str(episode.duration // 60000) if episode.duration else "0",
                "rating": str(episode.rating) if episode.rating else "0",
                "season": episode.seasonNumber,
                "cover_big": f"{PLEX_URL}{episode.thumb}?X-Plex-Token={PLEX_TOKEN}" if episode.thumb else ""
            },
            "direct_source": stream_url
        }
    except Exception as e:
        print(f"Error formatting episode {episode.title}: {e}")
        return None

# Xtream Codes API Endpoints

@app.route('/player_api.php')
def player_api():
    """Main Xtream Codes API endpoint"""
    if not plex:
        return jsonify({"error": "Plex server not connected"}), 500
    
    action = request.args.get('action')
    
    if not validate_session():
        return jsonify({
            "user_info": {"auth": 0, "status": "Expired", "message": "Invalid credentials"}
        }), 401
    
    # Authentication endpoint
    if action is None and request.args.get('username') and request.args.get('password'):
        server_info = {
            "url": PLEX_URL,
            "port": BRIDGE_PORT,
            "https_port": "",
            "server_protocol": "http",
            "rtmp_port": "",
            "timezone": "UTC",
            "timestamp_now": int(time.time()),
            "time_now": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
        
        user_info = {
            "username": request.args.get('username'),
            "password": request.args.get('password'),
            "message": "Welcome to Plex Bridge",
            "auth": 1,
            "status": "Active",
            "exp_date": "9999999999",
            "is_trial": "0",
            "active_cons": "1",
            "created_at": str(int(time.time())),
            "max_connections": "5",
            "allowed_output_formats": ["m3u8", "ts"]
        }
        
        return jsonify({
            "user_info": user_info,
            "server_info": server_info
        })
    
    # Get VOD categories
    elif action == 'get_vod_categories':
        categories = []
        for section in plex.library.sections():
            if section.type == 'movie':
                categories.append({
                    "category_id": section.key,
                    "category_name": section.title,
                    "parent_id": 0
                })
        return jsonify(categories)
    
    # Get VOD streams (movies)
    elif action == 'get_vod_streams':
        category_id = request.args.get('category_id')
        movies = []
        
        if category_id:
            try:
                section = plex.library.sectionByID(int(category_id))
                for movie in section.all():
                    formatted = format_movie_for_xtream(movie, category_id)
                    if formatted:
                        movies.append(formatted)
            except Exception as e:
                print(f"Error getting movies: {e}")
        else:
            for section in plex.library.sections():
                if section.type == 'movie':
                    for movie in section.all():
                        formatted = format_movie_for_xtream(movie, section.key)
                        if formatted:
                            movies.append(formatted)
        
        return jsonify(movies)
    
    # Get VOD info
    elif action == 'get_vod_info':
        vod_id = request.args.get('vod_id')
        if not vod_id:
            return jsonify({"error": "Missing vod_id"}), 400
        
        try:
            movie = plex.fetchItem(int(vod_id))
            stream_url = get_stream_url(movie)
            
            info = {
                "info": {
                    "tmdb_id": "",
                    "name": movie.title,
                    "o_name": movie.originalTitle or movie.title,
                    "cover_big": f"{PLEX_URL}{movie.art}?X-Plex-Token={PLEX_TOKEN}" if movie.art else "",
                    "movie_image": f"{PLEX_URL}{movie.thumb}?X-Plex-Token={PLEX_TOKEN}" if movie.thumb else "",
                    "releasedate": str(movie.year) if movie.year else "",
                    "youtube_trailer": "",
                    "director": ", ".join([d.tag for d in movie.directors]) if movie.directors else "",
                    "actors": ", ".join([a.tag for a in movie.roles[:10]]) if movie.roles else "",
                    "cast": ", ".join([a.tag for a in movie.roles[:10]]) if movie.roles else "",
                    "description": movie.summary or "",
                    "plot": movie.summary or "",
                    "age": movie.contentRating or "",
                    "rating": str(movie.rating) if movie.rating else "0",
                    "rating_5based": round(float(movie.rating or 0) / 2, 1),
                    "duration_secs": str(movie.duration // 1000) if movie.duration else "0",
                    "duration": str(movie.duration // 60000) if movie.duration else "0",
                    "genre": ", ".join([g.tag for g in movie.genres]) if movie.genres else "",
                    "backdrop_path": [f"{PLEX_URL}{movie.art}?X-Plex-Token={PLEX_TOKEN}"] if movie.art else []
                },
                "movie_data": {
                    "stream_id": movie.ratingKey,
                    "name": movie.title,
                    "container_extension": "mkv",
                    "custom_sid": "",
                    "direct_source": stream_url
                }
            }
            return jsonify(info)
        except Exception as e:
            return jsonify({"error": str(e)}), 404
    
    # Get series categories
    elif action == 'get_series_categories':
        categories = []
        for section in plex.library.sections():
            if section.type == 'show':
                categories.append({
                    "category_id": section.key,
                    "category_name": section.title,
                    "parent_id": 0
                })
        return jsonify(categories)
    
    # Get series
    elif action == 'get_series':
        category_id = request.args.get('category_id')
        series_list = []
        
        if category_id:
            try:
                section = plex.library.sectionByID(int(category_id))
                for show in section.all():
                    formatted = format_series_for_xtream(show, category_id)
                    if formatted:
                        series_list.append(formatted)
            except Exception as e:
                print(f"Error getting series: {e}")
        else:
            for section in plex.library.sections():
                if section.type == 'show':
                    for show in section.all():
                        formatted = format_series_for_xtream(show, section.key)
                        if formatted:
                            series_list.append(formatted)
        
        return jsonify(series_list)
    
    # Get series info
    elif action == 'get_series_info':
        series_id = request.args.get('series_id')
        if not series_id:
            return jsonify({"error": "Missing series_id"}), 400
        
        try:
            show = plex.fetchItem(int(series_id))
            
            # Get all seasons and episodes
            seasons = {}
            episodes_data = {}
            
            for season in show.seasons():
                season_num = season.seasonNumber
                if season_num is None:
                    continue
                    
                seasons[season_num] = {
                    "air_date": str(season.year) if hasattr(season, 'year') and season.year else "",
                    "episode_count": len(season.episodes()),
                    "id": season.ratingKey,
                    "name": season.title,
                    "overview": season.summary or "",
                    "season_number": season_num,
                    "cover": f"{PLEX_URL}{season.thumb}?X-Plex-Token={PLEX_TOKEN}" if season.thumb else "",
                    "cover_big": f"{PLEX_URL}{season.art}?X-Plex-Token={PLEX_TOKEN}" if hasattr(season, 'art') and season.art else ""
                }
                
                episodes = []
                for episode in season.episodes():
                    formatted_episode = format_episode_for_xtream(episode, series_id)
                    if formatted_episode:
                        episodes.append(formatted_episode)
                
                if episodes:
                    episodes_data[season_num] = episodes
            
            info = {
                "seasons": list(seasons.values()),
                "info": {
                    "name": show.title,
                    "cover": f"{PLEX_URL}{show.thumb}?X-Plex-Token={PLEX_TOKEN}" if show.thumb else "",
                    "plot": show.summary or "",
                    "cast": ", ".join([actor.tag for actor in show.roles[:10]]) if show.roles else "",
                    "director": ", ".join([d.tag for d in show.directors]) if show.directors else "",
                    "genre": ", ".join([g.tag for g in show.genres]) if show.genres else "",
                    "releaseDate": str(show.year) if show.year else "",
                    "rating": str(show.rating) if show.rating else "0",
                    "rating_5based": round(float(show.rating or 0) / 2, 1),
                    "backdrop_path": [f"{PLEX_URL}{show.art}?X-Plex-Token={PLEX_TOKEN}"] if show.art else [],
                    "youtube_trailer": "",
                    "episode_run_time": "",
                    "category_id": "2"
                },
                "episodes": episodes_data
            }
            
            return jsonify(info)
        except Exception as e:
            return jsonify({"error": str(e)}), 404
    
    return jsonify({"error": "Unknown action"}), 400

@app.route('/movie/<username>/<password>/<stream_id>.mkv')
@app.route('/movie/<username>/<password>/<stream_id>.mp4')
def stream_movie(username, password, stream_id):
    """Stream a movie"""
    if not authenticate(username, password):
        return "Unauthorized", 401
    
    try:
        movie = plex.fetchItem(int(stream_id))
        stream_url = get_stream_url(movie)
        if stream_url:
            return Response(
                status=302,
                headers={'Location': stream_url}
            )
        return "Stream not found", 404
    except Exception as e:
        return str(e), 404

@app.route('/series/<username>/<password>/<stream_id>.mkv')
@app.route('/series/<username>/<password>/<stream_id>.mp4')
def stream_episode(username, password, stream_id):
    """Stream a TV episode"""
    if not authenticate(username, password):
        return "Unauthorized", 401
    
    try:
        episode = plex.fetchItem(int(stream_id))
        stream_url = get_stream_url(episode)
        if stream_url:
            return Response(
                status=302,
                headers={'Location': stream_url}
            )
        return "Stream not found", 404
    except Exception as e:
        return str(e), 404

@app.route('/')
def index():
    """Root endpoint with info"""
    return jsonify({
        "service": "Plex to Xtream Codes Bridge",
        "status": "running",
        "plex_connected": plex is not None,
        "plex_server": plex.friendlyName if plex else "Not connected",
        "endpoints": {
            "authentication": "/player_api.php?username=X&password=Y",
            "vod_categories": "/player_api.php?username=X&password=Y&action=get_vod_categories",
            "vod_streams": "/player_api.php?username=X&password=Y&action=get_vod_streams",
            "series_categories": "/player_api.php?username=X&password=Y&action=get_series_categories",
            "series": "/player_api.php?username=X&password=Y&action=get_series",
        }
    })

if __name__ == '__main__':
    print("=" * 60)
    print("Plex to Xtream Codes API Bridge")
    print("=" * 60)
    print(f"Bridge URL: http://{BRIDGE_HOST}:{BRIDGE_PORT}")
    print(f"Username: {BRIDGE_USERNAME}")
    print(f"Password: {BRIDGE_PASSWORD}")
    print("=" * 60)
    
    app.run(host=BRIDGE_HOST, port=BRIDGE_PORT, debug=False, threaded=True)
