# 🔍 TV Shows & Active Users Troubleshooting

## 🎯 Quick Fixes

### **Update the Bridge:**
```bash
sudo systemctl stop plex-xtream-bridge
cd ~/plex-xtream-bridge
# Copy new plex_xtream_bridge_web.py
sudo systemctl start plex-xtream-bridge
```

## 📺 TV Shows Not Showing

### **Test 1: Check If Plex Has TV Shows**
```bash
# List all Plex library sections
curl "http://YOUR_PLEX_IP:32400/library/sections?X-Plex-Token=YOUR_TOKEN"

# Look for: type="show"
# Example: <Directory ... type="show" title="TV Shows" ...>
```

**If you see `type="show"`** → Plex has TV shows ✅
**If you don't see it** → Add TV library in Plex first ❌

### **Test 2: Check Bridge API**
```bash
# Get TV categories
curl "http://localhost:8080/player_api.php?username=admin&password=YOUR_PASSWORD&action=get_series_categories"

# Should return JSON like:
# [{"category_id": "2", "category_name": "📁 TV Shows", "parent_id": 0}, ...]
```

**If empty `[]`** → Check logs (see below)
**If has categories** → Good! ✅

### **Test 3: Get Actual TV Shows**
```bash
# Get all TV shows
curl "http://localhost:8080/player_api.php?username=admin&password=YOUR_PASSWORD&action=get_series"

# Should return array of shows
```

**If empty `[]`** → Check logs
**If has shows** → Bridge is working! ✅

### **Test 4: Check Logs**
```bash
# Watch logs in real-time
sudo journalctl -u plex-xtream-bridge -f

# Then make request from step 3 again
```

**Look for:**
```
[DEBUG] get_series called with category_id: None
[DEBUG] Returning all series from all sections
[DEBUG] Processing TV section: TV Shows
[DEBUG] Returning 25 TV shows
```

**If you see:**
- `Processing TV section:` → Plex library found ✅
- `Returning 0 TV shows` → No shows in library or formatting error ❌
- No debug messages → Request not reaching bridge ❌

### **Common Issues:**

**1. Wrong Credentials in Player:**
```
Check your player settings:
- Username: Matches bridge settings
- Password: Matches bridge settings
- URL: http://YOUR_IP:8080 (no /player_api.php)
```

**2. Plex Library Empty:**
```bash
# Check if Plex actually has shows
# Go to Plex web interface
# Navigate to TV Shows library
# If empty → Add TV shows to Plex first!
```

**3. Section Type Wrong:**
```bash
# Verify section is type "show" not "movie"
curl "http://YOUR_PLEX_IP:32400/library/sections?X-Plex-Token=TOKEN"
```

## 👥 Active Users Not Counting

### **Understanding Tracking:**

Active users are tracked when:
1. ✅ User requests movie/episode info (`get_vod_info` or `get_series_info`)
2. ✅ User actually starts streaming
3. ✅ Activity within last 5 minutes

NOT tracked:
- ❌ Just browsing categories
- ❌ Just looking at metadata
- ❌ Using Plex app directly (bypassing bridge)

### **Test Active User Tracking:**

**Step 1: Check Dashboard**
```
Open: http://YOUR_IP:8080/admin
Should show: "0 connected" initially
```

**Step 2: Request Movie Info**
```bash
# Simulate user clicking on a movie
curl "http://localhost:8080/player_api.php?username=admin&password=YOUR_PASSWORD&action=get_vod_info&vod_id=12345"

# Replace 12345 with actual movie ID from your library
```

**Step 3: Refresh Dashboard**
```
Reload: http://YOUR_IP:8080/admin
Should now show: "1 connected"
```

**If still shows 0:**

Check logs:
```bash
sudo journalctl -u plex-xtream-bridge -f
```

Make request again and look for:
```
GET /player_api.php?username=admin&password=...&action=get_vod_info&vod_id=12345
```

### **Chilli App Specific:**

Chilli/TiviMate/IPTV Smarters track differently:

**When you play content:**
1. App requests `get_vod_info` or `get_series_info`
2. Bridge tracks this user as active ✅
3. Dashboard updates

**To verify:**
1. Open Chilli app
2. Click on a movie (don't play yet, just click)
3. Check dashboard - should show 1 connected
4. Wait 6 minutes without activity
5. Dashboard drops to 0

### **Debug Active Users:**

**Check Active Streams:**

Add this temporarily to view tracking:
```bash
# SSH into server
cd ~/plex-xtream-bridge

# Add debug endpoint (temporary)
# This shows current active streams
```

Or check via Python:
```python
# In bridge code, add:
@app.route('/admin/debug-streams')
@require_admin_login
def debug_streams():
    cleanup_inactive_streams()
    return jsonify({
        'active_streams': active_streams,
        'unique_users': get_active_user_count()
    })
```

Then visit: `http://YOUR_IP:8080/admin/debug-streams`

### **Common Issues:**

**1. Player Caches Stream URLs:**
```
Some players cache the direct Plex URL
They bypass the bridge after first request
Result: Only counts first time
```

**2. Direct Plex Access:**
```
If player connects to Plex directly
Bridge doesn't see the request
Result: Not counted
```

**3. Timeout Too Short:**
```
Current: 5 minutes
If user pauses > 5 min → Removed from count
This is normal behavior
```

## 🎯 Expected Behavior

### **TV Shows:**
```
1. Player requests: get_series_categories
   → Bridge returns: All TV categories

2. Player requests: get_series&category_id=2
   → Bridge returns: Shows in category 2

3. User clicks show → requests: get_series_info&series_id=123
   → Bridge returns: Episodes list
   → User tracked as active

4. User plays episode
   → Stream starts
   → User remains active (refreshed)
```

### **Active Users:**
```
User A clicks movie → Count: 1
User B clicks show → Count: 2
User A stops watching → Still 2 (for 5 min)
5 minutes pass → Count: 1
User B stops → Still 1 (for 5 min)
5 minutes pass → Count: 0
```

## 📊 Verification Commands

**Complete Test Suite:**

```bash
# 1. Check Plex has TV
curl -s "http://PLEX_IP:32400/library/sections?X-Plex-Token=TOKEN" | grep 'type="show"'

# 2. Get bridge TV categories
curl -s "http://localhost:8080/player_api.php?username=admin&password=PASS&action=get_series_categories" | jq .

# 3. Get TV shows
curl -s "http://localhost:8080/player_api.php?username=admin&password=PASS&action=get_series" | jq '. | length'

# 4. Simulate user activity
curl -s "http://localhost:8080/player_api.php?username=admin&password=PASS&action=get_vod_info&vod_id=123"

# 5. Check dashboard
curl -s "http://localhost:8080/admin" | grep "connected"
```

## ✅ Success Indicators

**TV Shows Working:**
- ✓ get_series_categories returns categories
- ✓ get_series returns shows
- ✓ Shows appear in player
- ✓ Episodes load when clicked

**Active Users Working:**
- ✓ Dashboard shows 0 initially
- ✓ Count increases when playing
- ✓ Count decreases after 5 min inactivity
- ✓ Multiple users show separate counts

## 🆘 Still Not Working?

**Collect this info:**

1. **Plex library check:**
```bash
curl "http://PLEX_IP:32400/library/sections?X-Plex-Token=TOKEN"
```

2. **Bridge API response:**
```bash
curl "http://localhost:8080/player_api.php?username=admin&password=PASS&action=get_series"
```

3. **Logs during request:**
```bash
sudo journalctl -u plex-xtream-bridge -n 100 --no-pager
```

4. **Bridge configuration:**
```bash
cat ~/plex-xtream-bridge/config.json
```

Share these outputs for further troubleshooting!
