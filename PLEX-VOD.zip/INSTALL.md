# Quick Installation Guide

## 📦 You've extracted the ZIP file - Great!

Now you're in the project directory with all the files.

## 🚀 Install in 3 Steps:

### **Step 1: Make sure you're in the right place**

```bash
# Check you're in the directory with the files
ls -la

# You should see:
# plex_xtream_bridge_web.py
# install.sh
# requirements.txt
# etc.
```

### **Step 2: Run the installer**

```bash
# Make the installer executable
chmod +x install.sh

# Run it (it will install everything in THIS directory)
./install.sh --install-service
```

### **Step 3: Configure and use**

Visit: `http://YOUR_SERVER_IP:8080/admin`

**Default login:**
- Username: `admin`
- Password: `admin123` (you'll change this on first login)

**Configure:**
1. Plex Server URL (e.g., `http://192.168.1.100:32400`)
2. Plex Token ([how to get it](https://support.plex.tv/articles/204059436-finding-an-authentication-token-x-plex-token/))
3. TMDb API Key (optional, [get it free](https://www.themoviedb.org/settings/api))

**Done!** 🎉

---

## 🐳 Alternative: Docker (Even Easier)

If you prefer Docker:

```bash
# Build the image
docker build -t plex-vod:latest .

# Run it
docker run -d \
  --name plex-vod \
  -p 8080:8080 \
  -v $(pwd)/data:/app/data \
  -e MAX_MOVIES=10000 \
  -e MAX_SHOWS=5000 \
  --restart unless-stopped \
  plex-vod:latest
```

---

## 📂 What Gets Installed Where

Everything stays in **THIS DIRECTORY**:

```
/docker/PLEX-VOD/               ← Your current directory
├── plex_xtream_bridge_web.py  ← Main app
├── venv/                       ← Python virtual environment
├── data/                       ← Your data (config, cache)
│   ├── config.json             ← Settings
│   └── tmdb_cache.json         ← TMDb cache
└── install.sh                  ← This installer
```

---

## 🔧 Manage the Service

```bash
# Check status
sudo systemctl status plex-xtream-bridge

# View logs
sudo journalctl -u plex-xtream-bridge -f

# Restart
sudo systemctl restart plex-xtream-bridge

# Stop
sudo systemctl stop plex-xtream-bridge
```

---

## 📱 Add to IPTV App

**In TiviMate, IPTV Smarters, or Chilio:**

- **Server**: `http://YOUR_SERVER_IP:8080`
- **Username**: `admin` (or what you set)
- **Password**: Your bridge password
- **Type**: Xtream Codes API

---

## ❓ Need Help?

- Check the full **README.md** for detailed docs
- See **TROUBLESHOOTING.md** for common issues
- Check logs: `sudo journalctl -u plex-xtream-bridge -f`

---

**That's it! You're all set!** 🚀
