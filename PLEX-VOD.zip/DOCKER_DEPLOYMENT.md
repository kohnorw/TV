# Plex Xtream Bridge - Docker Deployment Guide

## 🐳 Quick Start with Docker

### Option 1: Docker Run (Simplest)

```bash
docker run -d \
  --name plex-xtream-bridge \
  --restart unless-stopped \
  -p 8080:8080 \
  -v $(pwd)/data:/app/data \
  -e TZ=America/New_York \
  plex-xtream-bridge:latest
```

### Option 2: Docker Compose

1. Create `docker-compose.yml`:

```yaml
version: '3.8'

services:
  plex-xtream-bridge:
    image: plex-xtream-bridge:latest
    container_name: plex-xtream-bridge
    restart: unless-stopped
    ports:
      - "8080:8080"
    volumes:
      - ./data:/app/data
    environment:
      - BRIDGE_HOST=0.0.0.0
      - BRIDGE_PORT=8080
      - TZ=America/New_York
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8080/player_api.php"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 40s
```

2. Run:

```bash
docker-compose up -d
```

### Option 3: Portainer Stack

1. Go to Portainer → Stacks → Add Stack
2. Paste this:

```yaml
version: '3.8'

services:
  plex-xtream-bridge:
    image: plex-xtream-bridge:latest
    container_name: plex-xtream-bridge
    restart: unless-stopped
    ports:
      - "8080:8080"
    volumes:
      - plex-xtream-data:/app/data
    environment:
      - BRIDGE_HOST=0.0.0.0
      - BRIDGE_PORT=8080
      - TZ=America/New_York
    healthcheck:
      test: ["CMD-SHELL", "python -c 'import requests; requests.get(\"http://localhost:8080/admin/login\", timeout=5)' || exit 1"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 40s

volumes:
  plex-xtream-data:
```

3. Click "Deploy the stack"

## 🏗️ Building the Docker Image

### Build locally:

```bash
# Clone or download the files
cd plex-xtream-bridge

# Build the image
docker build -t plex-xtream-bridge:latest .

# Run it
docker run -d \
  --name plex-xtream-bridge \
  -p 8080:8080 \
  -v $(pwd)/data:/app/data \
  plex-xtream-bridge:latest
```

### Push to Docker Hub (optional):

```bash
# Tag for Docker Hub
docker tag plex-xtream-bridge:latest yourusername/plex-xtream-bridge:latest

# Push
docker push yourusername/plex-xtream-bridge:latest
```

## 📂 File Structure

```
plex-xtream-bridge/
├── Dockerfile
├── docker-compose.yml
├── requirements.txt
├── plex_xtream_bridge_web.py
└── data/
    ├── config.json       (auto-created)
    └── tmdb_cache.json   (auto-created)
```

## 🔧 Configuration

### First Time Setup:

1. Start the container
2. Access: `http://YOUR_SERVER_IP:8080/admin`
3. Login with default password: `admin123`
4. Change password (required)
5. Configure Plex URL and token
6. (Optional) Add TMDb API key

### Environment Variables:

| Variable | Default | Description |
|----------|---------|-------------|
| BRIDGE_HOST | 0.0.0.0 | Bind address |
| BRIDGE_PORT | 8080 | Port to listen on |
| TZ | UTC | Timezone |

### Volumes:

| Container Path | Description |
|---------------|-------------|
| /app/data | Config and cache files |

### Ports:

| Port | Description |
|------|-------------|
| 8080 | Web interface & API |

## 🎯 Access Points

- **Web Admin**: `http://YOUR_IP:8080/admin`
- **API Endpoint**: `http://YOUR_IP:8080/player_api.php`
- **Default Username**: `admin`
- **Default Password**: `admin123` (change on first login)

## 🔍 Troubleshooting

### Check logs:

```bash
docker logs plex-xtream-bridge
```

### Check if running:

```bash
docker ps | grep plex-xtream-bridge
```

### Restart container:

```bash
docker restart plex-xtream-bridge
```

### Access container shell:

```bash
docker exec -it plex-xtream-bridge /bin/bash
```

### View data files:

```bash
# If using bind mount
ls -la ./data/

# If using volume
docker volume inspect plex-xtream-data
```

## 📊 Health Check

The container includes a health check that runs every 30 seconds:

```bash
# Check health status
docker inspect --format='{{.State.Health.Status}}' plex-xtream-bridge
```

Status should be: `healthy`

## 🔄 Updating

```bash
# Pull new image
docker pull plex-xtream-bridge:latest

# Stop and remove old container
docker stop plex-xtream-bridge
docker rm plex-xtream-bridge

# Start new container (your data persists!)
docker run -d \
  --name plex-xtream-bridge \
  -p 8080:8080 \
  -v $(pwd)/data:/app/data \
  plex-xtream-bridge:latest
```

Or with docker-compose:

```bash
docker-compose pull
docker-compose up -d
```

## 🌐 Network Configuration

### Host Network Mode (optional):

```bash
docker run -d \
  --name plex-xtream-bridge \
  --network host \
  -v $(pwd)/data:/app/data \
  plex-xtream-bridge:latest
```

### Custom Network:

```bash
# Create network
docker network create plex-network

# Run container
docker run -d \
  --name plex-xtream-bridge \
  --network plex-network \
  -p 8080:8080 \
  -v $(pwd)/data:/app/data \
  plex-xtream-bridge:latest
```

## 🎬 Features

- ✅ Plex to Xtream Codes API bridge
- ✅ Web admin interface
- ✅ TMDb metadata integration (optional)
- ✅ Auto-matching every 30 minutes
- ✅ Manual TMDb matching interface
- ✅ Search and fix matches
- ✅ Persistent cache
- ✅ Multi-user support
- ✅ Secure password hashing
- ✅ Encrypted config storage

## 📝 Notes

- Config and cache persist in the `/app/data` volume
- First login requires password change
- TMDb API key is optional but recommended
- Auto-matching runs on startup if TMDb is configured
- Cache survives container restarts
