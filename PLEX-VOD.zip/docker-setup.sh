#!/bin/bash
# Docker Quick Setup Script for Plex Xtream Bridge

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

echo -e "${BLUE}"
echo "============================================================"
echo "  Plex Xtream Bridge - Docker Setup"
echo "============================================================"
echo -e "${NC}"

# Check if Docker is installed
if ! command -v docker &> /dev/null; then
    echo -e "${RED}Docker is not installed!${NC}"
    echo ""
    echo "Install Docker first:"
    echo "  curl -fsSL https://get.docker.com | sh"
    echo "  sudo usermod -aG docker $USER"
    echo ""
    exit 1
fi

# Check if docker-compose is installed
if ! command -v docker-compose &> /dev/null; then
    echo -e "${YELLOW}docker-compose not found, checking for docker compose plugin...${NC}"
    if ! docker compose version &> /dev/null; then
        echo -e "${RED}Neither docker-compose nor docker compose plugin found!${NC}"
        echo ""
        echo "Install docker-compose:"
        echo "  sudo apt install docker-compose"
        echo ""
        exit 1
    fi
    COMPOSE_CMD="docker compose"
else
    COMPOSE_CMD="docker-compose"
fi

echo -e "${GREEN}✓ Docker found${NC}"
echo -e "${GREEN}✓ Compose found${NC}"
echo ""

# Check required files
REQUIRED_FILES=("Dockerfile" "docker-compose.yml" "plex_xtream_bridge_web.py" "requirements.txt")
MISSING_FILES=()

for file in "${REQUIRED_FILES[@]}"; do
    if [ ! -f "$file" ]; then
        MISSING_FILES+=("$file")
    fi
done

if [ ${#MISSING_FILES[@]} -ne 0 ]; then
    echo -e "${RED}Missing required files:${NC}"
    for file in "${MISSING_FILES[@]}"; do
        echo "  - $file"
    done
    echo ""
    echo "Please ensure all files are in the current directory."
    exit 1
fi

echo -e "${GREEN}✓ All required files present${NC}"
echo ""

# Create data directory
mkdir -p data
echo -e "${GREEN}✓ Created data directory${NC}"

# Parse command line arguments
ACTION=${1:-build}

case $ACTION in
    build)
        echo ""
        echo -e "${CYAN}Building Docker image...${NC}"
        $COMPOSE_CMD build --no-cache
        echo ""
        echo -e "${GREEN}✓ Build complete!${NC}"
        echo ""
        echo -e "${YELLOW}Next steps:${NC}"
        echo "  $0 start      # Start the container"
        echo "  $0 logs       # View logs"
        ;;
    
    start)
        echo ""
        echo -e "${CYAN}Starting container...${NC}"
        $COMPOSE_CMD up -d
        echo ""
        
        # Wait for container to be healthy
        echo "Waiting for container to be ready..."
        sleep 5
        
        if $COMPOSE_CMD ps | grep -q "Up"; then
            SERVER_IP=$(hostname -I | awk '{print $1}')
            echo -e "${GREEN}✓ Container started successfully!${NC}"
            echo ""
            echo -e "${CYAN}Access the bridge at:${NC}"
            echo "  Web Interface: ${GREEN}http://$SERVER_IP:8080/admin${NC}"
            echo "  Default Login: ${GREEN}admin123${NC}"
            echo ""
            echo -e "${YELLOW}Remember to change the password on first login!${NC}"
        else
            echo -e "${RED}✗ Container failed to start${NC}"
            echo "Check logs with: $0 logs"
        fi
        ;;
    
    stop)
        echo ""
        echo -e "${CYAN}Stopping container...${NC}"
        $COMPOSE_CMD down
        echo -e "${GREEN}✓ Container stopped${NC}"
        ;;
    
    restart)
        echo ""
        echo -e "${CYAN}Restarting container...${NC}"
        $COMPOSE_CMD restart
        echo -e "${GREEN}✓ Container restarted${NC}"
        ;;
    
    logs)
        echo ""
        echo -e "${CYAN}Showing logs (Ctrl+C to exit)...${NC}"
        echo ""
        $COMPOSE_CMD logs -f
        ;;
    
    status)
        echo ""
        $COMPOSE_CMD ps
        ;;
    
    shell)
        echo ""
        echo -e "${CYAN}Opening shell in container...${NC}"
        $COMPOSE_CMD exec plex-xtream-bridge /bin/bash
        ;;
    
    update)
        echo ""
        echo -e "${CYAN}Updating container...${NC}"
        echo ""
        
        # Backup
        echo "Creating backup..."
        if [ -d "data" ]; then
            cp -r data data.backup.$(date +%Y%m%d_%H%M%S)
            echo -e "${GREEN}✓ Backup created${NC}"
        fi
        
        # Stop
        echo "Stopping container..."
        $COMPOSE_CMD down
        
        # Rebuild
        echo "Rebuilding..."
        $COMPOSE_CMD build --no-cache
        
        # Start
        echo "Starting..."
        $COMPOSE_CMD up -d
        
        echo ""
        echo -e "${GREEN}✓ Update complete!${NC}"
        ;;
    
    clean)
        echo ""
        echo -e "${YELLOW}This will remove the container and image (data will be preserved)${NC}"
        read -p "Are you sure? (y/N): " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            $COMPOSE_CMD down
            docker rmi plex-xtream-bridge_plex-xtream-bridge 2>/dev/null || true
            echo -e "${GREEN}✓ Cleaned up${NC}"
        else
            echo "Cancelled"
        fi
        ;;
    
    help|--help|-h)
        echo "Plex Xtream Bridge - Docker Setup Script"
        echo ""
        echo "Usage: $0 [command]"
        echo ""
        echo "Commands:"
        echo "  build       Build the Docker image"
        echo "  start       Start the container"
        echo "  stop        Stop the container"
        echo "  restart     Restart the container"
        echo "  logs        View container logs"
        echo "  status      Show container status"
        echo "  shell       Open shell in container"
        echo "  update      Update and rebuild container"
        echo "  clean       Remove container and image"
        echo "  help        Show this help message"
        echo ""
        echo "Examples:"
        echo "  $0 build && $0 start    # Build and start"
        echo "  $0 logs                 # View logs"
        echo "  $0 restart              # Restart"
        ;;
    
    *)
        echo -e "${RED}Unknown command: $ACTION${NC}"
        echo "Run '$0 help' for usage"
        exit 1
        ;;
esac
