#!/usr/bin/env python3
"""
Fix cache structure - migrate 'seriess' to 'series'
"""
import json
import os
import shutil

cache_paths = ['data/metadata_cache.json', 'metadata_cache.json']
cache_file = None

# Find cache file
for path in cache_paths:
    if os.path.exists(path):
        cache_file = path
        break

if not cache_file:
    print("❌ No cache file found")
    exit(1)

print(f"📂 Found cache: {cache_file}")

# Backup first
backup = cache_file + '.backup'
shutil.copy(cache_file, backup)
print(f"💾 Backup created: {backup}")

# Load cache
with open(cache_file, 'r') as f:
    cache = json.load(f)

print("\n📊 Current cache structure:")
for key in cache.keys():
    if isinstance(cache[key], dict):
        print(f"  {key}: {len(cache[key])} items")
    else:
        print(f"  {key}: {cache[key]}")

# Fix the bug
fixed = False

if 'seriess' in cache:
    print(f"\n🔧 Migrating 'seriess' -> 'series'")
    
    if 'series' in cache:
        # Merge
        print(f"  Merging {len(cache['seriess'])} items into existing 'series'")
        cache['series'].update(cache['seriess'])
    else:
        # Rename
        print(f"  Moving {len(cache['seriess'])} items to 'series'")
        cache['series'] = cache['seriess']
    
    del cache['seriess']
    fixed = True

# Save fixed cache
if fixed:
    with open(cache_file, 'w') as f:
        json.dump(cache, f, indent=2)
    
    print("\n✅ Cache fixed!")
    print("\n📊 New cache structure:")
    for key in cache.keys():
        if isinstance(cache[key], dict):
            print(f"  {key}: {len(cache[key])} items")
        else:
            print(f"  {key}: {cache[key]}")
    
    print(f"\n🔄 Now restart the bridge:")
    print(f"  sudo systemctl restart plex-xtream-bridge")
else:
    print("\n✅ No issues found - cache structure is correct")
