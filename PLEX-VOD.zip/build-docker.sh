#!/bin/bash
# Docker Build Script for Plex Xtream Bridge

set -e

BLUE='\033[0;34m'
GREEN='\033[0;32m'
RED='\033[0;31m'
NC='\033[0m'

IMAGE_NAME="plex-xtream-bridge"
VERSION="${1:-latest}"

echo -e "${BLUE}════════════════════════════════════════${NC}"
echo -e "${BLUE}  Plex Xtream Bridge - Docker Build${NC}"
echo -e "${BLUE}════════════════════════════════════════${NC}"

# Check if Dockerfile exists
if [ ! -f "Dockerfile" ]; then
    echo -e "${RED}ERROR: Dockerfile not found!${NC}"
    exit 1
fi

# Check if plex_xtream_bridge_web.py exists
if [ ! -f "plex_xtream_bridge_web.py" ]; then
    echo -e "${RED}ERROR: plex_xtream_bridge_web.py not found!${NC}"
    exit 1
fi

echo -e "\n${GREEN}[1/4] Building Docker image...${NC}"
docker build -t ${IMAGE_NAME}:${VERSION} .

echo -e "\n${GREEN}[2/4] Tagging as latest...${NC}"
docker tag ${IMAGE_NAME}:${VERSION} ${IMAGE_NAME}:latest

echo -e "\n${GREEN}[3/4] Image built successfully!${NC}"
docker images | grep ${IMAGE_NAME}

echo -e "\n${GREEN}[4/4] Build complete!${NC}"
echo -e "\n${BLUE}════════════════════════════════════════${NC}"
echo -e "${BLUE}  Quick Start Commands${NC}"
echo -e "${BLUE}════════════════════════════════════════${NC}"
echo -e "\n${GREEN}Run with Docker:${NC}"
echo "docker run -d --name plex-xtream-bridge -p 8080:8080 -v \$(pwd)/data:/app/data ${IMAGE_NAME}:latest"
echo -e "\n${GREEN}Run with Docker Compose:${NC}"
echo "docker-compose up -d"
echo -e "\n${GREEN}Access web interface:${NC}"
echo "http://YOUR_SERVER_IP:8080/admin"
echo -e "\n${BLUE}════════════════════════════════════════${NC}"
