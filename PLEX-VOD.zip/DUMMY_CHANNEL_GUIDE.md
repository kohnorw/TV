# Dummy Live TV Channel Feature

## 🎯 What's New

Added a **dummy Live TV info channel** to prevent 400 errors and make the Live TV section look complete in Xtream players!

## 📺 What You'll See

When you open the **Live TV** section in your player, you'll now see:

### Category:
- 📁 **"Plex Bridge Info"**

### Channels:
1. **📺 Plex Bridge - Info Channel**
   - Shows that the bridge is working
   - Confirms your connection

2. **📊 Library Stats**
   - Shows how many movie libraries you have
   - Shows how many TV libraries you have
   - Example: "📊 Library Stats: 3 Movie Libraries, 2 TV Libraries"

## 🎨 Why This Helps

### Before:
```
Live TV
└── (Empty - causes errors in some players)
```

### After:
```
Live TV
└── Plex Bridge Info
    ├── 📺 Plex Bridge - Info Channel
    └── 📊 Library Stats: 3 Movie Libraries, 2 TV Libraries
```

## ⚙️ Configuration

You can **enable or disable** this feature in Settings!

### To Toggle:

1. Go to `http://YOUR_SERVER_IP:8080/admin`
2. Click **"⚙️ Settings"**
3. Scroll to **"Advanced Options"**
4. Check/uncheck **"Show Info Channel in Live TV"**
5. Click **"💾 Save Settings"**

### When to Enable:
✅ You don't have Plex DVR/Live TV
✅ Your player shows errors with empty Live TV
✅ You want to see library stats in your player

### When to Disable:
❌ You have real Plex Live TV channels
❌ You prefer a completely empty Live TV section
❌ You only use VOD features

## 🔧 Technical Details

### What Happens:

**With No Plex DVR + Dummy Channel Enabled:**
- Creates category "Plex Bridge Info" (ID: 999)
- Adds 2 info "channels" (IDs: 99999, 99998)
- Returns proper 200 responses
- Players show filled Live TV section

**With No Plex DVR + Dummy Channel Disabled:**
- Returns empty arrays
- No Live TV category shown
- Clean, minimal interface

**With Real Plex DVR:**
- Dummy channels automatically hidden
- Real channels from Plex shown instead
- Bridge detects Live TV and uses it

## 📱 Player Behavior

### TiviMate:
- Shows "Plex Bridge Info" category
- Channels appear with icons
- Can be organized in groups

### IPTV Smarters:
- Info channels visible in Live TV tab
- Can refresh channel list
- Shows library stats

### GSE Smart IPTV:
- Channels load normally
- Can be favorited
- Channel list updates automatically

## 🎬 What the Dummy Channels Show

### Channel 1: Info Channel
```json
{
  "name": "📺 Plex Bridge - Info Channel",
  "stream_id": 99999,
  "category": "Plex Bridge Info"
}
```

### Channel 2: Library Stats
```json
{
  "name": "📊 Library Stats: 3 Movie Libraries, 2 TV Libraries",
  "stream_id": 99998,
  "category": "Plex Bridge Info"
}
```

## 🚀 Updating

### If Already Installed:

```bash
# Stop service
sudo systemctl stop plex-xtream-bridge

# Backup
cd ~/plex-xtream-bridge
cp plex_xtream_bridge_web.py plex_xtream_bridge_web.py.backup

# Copy new version
# ... download/upload the updated file ...

# Restart
sudo systemctl start plex-xtream-bridge
```

### After Update:

1. Refresh your player's channel list
2. Look for "Plex Bridge Info" in Live TV
3. Optional: Disable in Settings if you prefer

## 🧪 Testing

### Test the API:

```bash
# Get live categories
curl "http://localhost:8080/player_api.php?username=admin&password=admin&action=get_live_categories"

# Should return:
[{"category_id": "999", "category_name": "Plex Bridge Info", "parent_id": 0}]

# Get live streams
curl "http://localhost:8080/player_api.php?username=admin&password=admin&action=get_live_streams&category_id=999"

# Should return 2 channels
```

### Check Your Logs:

```bash
sudo journalctl -u plex-xtream-bridge -f
```

Look for:
```
[API] Request: action=get_live_categories, user=admin
192.168.1.193 - - [14/Feb/2026 22:00:00] "GET /player_api.php?username=admin&password=admin&action=get_live_categories HTTP/1.1" 200 -
```

**Status 200** = Success! ✅

## 💡 Advanced Customization

Want to add more dummy channels? Edit the code:

```python
# In get_live_streams endpoint, add more channels:
streams.append({
    "num": 3,
    "name": "Your Custom Channel Name",
    "stream_type": "live",
    "stream_id": 99997,
    "stream_icon": "https://your-icon-url.png",
    "category_id": "999",
    # ... other fields
})
```

## ❓ FAQ

**Q: Will these channels actually play?**
A: No, they're info-only. They won't stream anything when selected.

**Q: Can I hide them?**
A: Yes! Just disable "Show Info Channel in Live TV" in Settings.

**Q: Do they count toward my channel limit?**
A: No limits with this bridge! Add as many as you want.

**Q: Will they appear if I add real Plex DVR?**
A: No, the dummy channels automatically hide when real Live TV is detected.

**Q: Can I customize the names?**
A: Yes, but you'll need to edit the Python code directly.

**Q: Do they affect performance?**
A: Not at all - they're just metadata, no actual streaming.

## 🎉 Benefits

✅ **No More Errors** - 400 responses eliminated
✅ **Cleaner Interface** - Live TV section looks complete
✅ **Useful Info** - See your library stats right in the player
✅ **Better Compatibility** - Works with all Xtream players
✅ **Optional** - Can be disabled anytime
✅ **Smart** - Auto-hides when real Live TV exists

## 🔄 Before & After

### Logs Before:
```
"GET /player_api.php?username=admin&password=admin&action=get_live_categories HTTP/1.1" 400 -
```
❌ Error!

### Logs After:
```
[API] Request: action=get_live_categories, user=admin
"GET /player_api.php?username=admin&password=admin&action=get_live_categories HTTP/1.1" 200 -
```
✅ Success!

## 📝 Summary

This feature fills the Live TV section with helpful info channels so:
- Players don't show errors
- You can see your library stats
- The interface looks complete
- Everything works smoothly

You can toggle it on/off in Settings based on your preference!
