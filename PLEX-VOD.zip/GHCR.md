# GitHub Container Registry (ghcr.io) Setup Guide

This guide will help you publish your Docker image to GitHub Container Registry and use it in Portainer.

## 🚀 Quick Setup (Automatic)

### Step 1: Enable GitHub Actions

1. Go to your GitHub repository
2. Click **Settings** → **Actions** → **General**
3. Under "Workflow permissions", select:
   - ✅ **Read and write permissions**
   - ✅ **Allow GitHub Actions to create and approve pull requests**
4. Click **Save**

### Step 2: Push to GitHub

The GitHub Action will automatically:
- Build your Docker image
- Push to `ghcr.io/YOUR_USERNAME/plex-xtream-bridge`
- Support multiple platforms (amd64, arm64)
- Tag with `latest` and version numbers

```bash
git add .
git commit -m "Add GitHub Actions workflow"
git push origin main
```

### Step 3: Make Package Public (Optional)

1. Go to your GitHub profile
2. Click **Packages**
3. Click on **plex-xtream-bridge**
4. Click **Package settings**
5. Scroll down to **Danger Zone**
6. Click **Change visibility** → **Public**

Now anyone can pull your image!

---

## 📦 Using the Image

### From Docker:

```bash
docker pull ghcr.io/YOUR_USERNAME/plex-xtream-bridge:latest

docker run -d \
  --name plex-xtream-bridge \
  -p 8080:8080 \
  -v ./data:/app/data \
  --restart unless-stopped \
  ghcr.io/YOUR_USERNAME/plex-xtream-bridge:latest
```

### From Portainer:

Update your `docker-compose.yml`:

```yaml
version: '3.8'

services:
  plex-xtream-bridge:
    image: ghcr.io/YOUR_USERNAME/plex-xtream-bridge:latest
    container_name: plex-xtream-bridge
    restart: unless-stopped
    
    ports:
      - "8080:8080"
    
    volumes:
      - plex-bridge-data:/app/data
    
    environment:
      - BRIDGE_HOST=0.0.0.0
      - BRIDGE_PORT=8080

volumes:
  plex-bridge-data:
```

Deploy in Portainer:
1. **Stacks** → **+ Add stack**
2. Paste the compose file above
3. Replace `YOUR_USERNAME` with your GitHub username
4. **Deploy the stack**

---

## 🏷️ Versioning

### Automatic Tags

The GitHub Action creates these tags automatically:

- `latest` - Always points to the latest main branch
- `main` - Latest from main branch
- `v1.0.0` - Semantic version (when you create a Git tag)
- `v1.0` - Major.minor version
- `v1` - Major version only

### Create a Release

```bash
# Tag your release
git tag v1.0.0
git push origin v1.0.0

# GitHub Actions will build and push:
# - ghcr.io/YOUR_USERNAME/plex-xtream-bridge:latest
# - ghcr.io/YOUR_USERNAME/plex-xtream-bridge:v1.0.0
# - ghcr.io/YOUR_USERNAME/plex-xtream-bridge:v1.0
# - ghcr.io/YOUR_USERNAME/plex-xtream-bridge:v1
```

Use specific versions in production:

```yaml
services:
  plex-xtream-bridge:
    image: ghcr.io/YOUR_USERNAME/plex-xtream-bridge:v1.0.0
```

---

## 🔐 Private Packages (Authentication)

If your package is private, you need to authenticate:

### Generate Personal Access Token (PAT)

1. Go to GitHub → **Settings** → **Developer settings** → **Personal access tokens** → **Tokens (classic)**
2. Click **Generate new token (classic)**
3. Name it: `ghcr-pull-token`
4. Select scopes:
   - ✅ `read:packages`
   - ✅ `write:packages` (if pushing)
5. Click **Generate token**
6. **Copy the token** (you won't see it again!)

### Login to GHCR

```bash
echo "YOUR_PAT_TOKEN" | docker login ghcr.io -u YOUR_USERNAME --password-stdin
```

### Use in Portainer

1. Go to **Registries** in Portainer
2. Click **+ Add registry**
3. Fill in:
   - **Name**: GitHub Container Registry
   - **Registry URL**: `ghcr.io`
   - **Authentication**: ON
   - **Username**: Your GitHub username
   - **Password**: Your PAT token
4. Click **Add registry**

Now Portainer can pull private images!

---

## 🛠️ Manual Build & Push

If you prefer manual control:

```bash
# Login to GHCR
echo "YOUR_PAT_TOKEN" | docker login ghcr.io -u YOUR_USERNAME --password-stdin

# Build the image
docker build -t ghcr.io/YOUR_USERNAME/plex-xtream-bridge:latest .

# Push to GHCR
docker push ghcr.io/YOUR_USERNAME/plex-xtream-bridge:latest

# Tag a version
docker tag ghcr.io/YOUR_USERNAME/plex-xtream-bridge:latest \
           ghcr.io/YOUR_USERNAME/plex-xtream-bridge:v1.0.0

docker push ghcr.io/YOUR_USERNAME/plex-xtream-bridge:v1.0.0
```

---

## 🔄 Auto-Update in Portainer

### Option 1: Watchtower

Add Watchtower to auto-update containers:

```yaml
version: '3.8'

services:
  plex-xtream-bridge:
    image: ghcr.io/YOUR_USERNAME/plex-xtream-bridge:latest
    container_name: plex-xtream-bridge
    restart: unless-stopped
    ports:
      - "8080:8080"
    volumes:
      - plex-bridge-data:/app/data
    labels:
      - "com.centurylinklabs.watchtower.enable=true"

  watchtower:
    image: containrrr/watchtower
    container_name: watchtower
    restart: unless-stopped
    volumes:
      - /var/run/docker.sock:/var/run/docker.sock
    command: --interval 3600 --cleanup
    # Checks for updates every hour

volumes:
  plex-bridge-data:
```

### Option 2: Portainer Webhooks

1. In Portainer, go to your stack
2. Enable **Automatic updates**
3. Copy the webhook URL
4. Add to GitHub repository:
   - **Settings** → **Webhooks** → **Add webhook**
   - Paste the Portainer webhook URL
   - Select **Package** event

Now Portainer auto-updates when you push a new image!

---

## 📊 GitHub Actions Workflow Explained

The workflow (`.github/workflows/docker-publish.yml`) does:

1. **Triggers on:**
   - Push to `main` branch
   - Git tags starting with `v`
   - Manual workflow dispatch

2. **Builds for:**
   - `linux/amd64` (Intel/AMD)
   - `linux/arm64` (ARM, Raspberry Pi)

3. **Automatic caching:**
   - Uses GitHub Actions cache
   - Speeds up subsequent builds

4. **Security:**
   - Uses `GITHUB_TOKEN` (automatic)
   - No need to store credentials

---

## 🎯 Example Repository URLs

After setup, your image will be available at:

**Public:**
```
ghcr.io/YOUR_USERNAME/plex-xtream-bridge:latest
ghcr.io/YOUR_USERNAME/plex-xtream-bridge:v1.0.0
```

**View on GitHub:**
```
https://github.com/YOUR_USERNAME/plex-xtream-bridge/pkgs/container/plex-xtream-bridge
```

**Pull stats, downloads, and versions are visible on the package page!**

---

## 🐛 Troubleshooting

### Build fails with "permission denied"

1. Go to **Settings** → **Actions** → **General**
2. Enable **Read and write permissions**
3. Re-run the workflow

### Can't pull private image

1. Make sure you're logged in: `docker login ghcr.io`
2. Use correct PAT token with `read:packages` scope
3. Check package visibility (Public vs Private)

### Image not updating in Portainer

1. In Portainer, click **Recreate** not just **Restart**
2. Enable **Pull latest image** when recreating
3. Or use Watchtower for automatic updates

---

## ✅ Quick Checklist

- [ ] Enable GitHub Actions workflow permissions
- [ ] Push code to GitHub (triggers automatic build)
- [ ] Wait for Actions to complete (~5 minutes)
- [ ] Make package public (or setup authentication)
- [ ] Update docker-compose.yml with ghcr.io image
- [ ] Deploy in Portainer
- [ ] Test the container

---

## 🎉 Benefits of GHCR

- ✅ **Free** - Unlimited public images
- ✅ **Fast** - GitHub's global CDN
- ✅ **Integrated** - Works seamlessly with GitHub
- ✅ **Secure** - Automatic scanning and attestation
- ✅ **Multi-platform** - Supports ARM and x86
- ✅ **Versioned** - Automatic tagging and releases

---

Need help? Check the [GitHub Actions logs](https://github.com/YOUR_USERNAME/plex-xtream-bridge/actions) for build details!
