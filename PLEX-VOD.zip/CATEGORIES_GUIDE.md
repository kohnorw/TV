# 📚 Smart Categories Feature Guide

## 🎉 What's New

Your Plex Xtream Bridge now has **automatic smart categories**! Your content is now organized into helpful categories like "Recently Added", "Highly Rated", and genre-based collections.

## ✨ Auto-Generated Categories

### For Movies:
For each movie library, you automatically get:

1. **🆕 Recently Added** - Your newest 50 movies
2. **🎬 Recently Released** - Movies sorted by release date
3. **⭐ Highly Rated** - Your best-rated movies
4. **🎭 Genre Categories** - Automatic categories for every genre
   - Action
   - Comedy
   - Drama
   - Horror
   - Sci-Fi
   - Romance
   - Thriller
   - And all others in your library!

### For TV Shows:
For each TV library, you automatically get:

1. **🆕 Recently Added** - Your newest 50 shows
2. **📺 Recently Aired** - Shows sorted by air date
3. **⭐ Highly Rated** - Your best-rated shows
4. **🎭 Genre Categories** - Automatic categories for every genre

## 📱 How It Looks in Your Player

### Before:
```
Movies
└── Movies

TV Shows
└── TV Shows
```

### After:
```
Movies
├── 📁 Movies (all movies)
├── 🆕 Recently Added - Movies
├── 🎬 Recently Released - Movies  
├── ⭐ Highly Rated - Movies
├── 🎭 Action - Movies
├── 🎭 Comedy - Movies
├── 🎭 Drama - Movies
└── ... (all your genres)

TV Shows
├── 📁 TV Shows (all shows)
├── 🆕 Recently Added - TV Shows
├── 📺 Recently Aired - TV Shows
├── ⭐ Highly Rated - TV Shows
├── 🎭 Action - TV Shows
├── 🎭 Comedy - TV Shows
└── ... (all your genres)
```

## 🎯 How to Use

### In Your Xtream Player:

1. **Refresh your playlist** (or restart the app)
2. **Navigate to VOD (Movies)** - You'll see all the new categories!
3. **Navigate to Series** - Genre and smart categories appear here too!
4. **Browse by category** - Click any category to see filtered content

### In TiviMate:
- Categories appear in the VOD section
- Genres are automatically organized
- Can favorite specific categories

### In IPTV Smarters:
- All categories show in Movies/Series tabs
- Scroll through organized content
- Recently Added appears at the top

## ⚙️ Managing Categories

### Via Web Interface:

1. Go to `http://YOUR_SERVER_IP:8080/admin`
2. Click **"📚 Categories"**
3. View all your auto-generated categories
4. See what's available

### Categories are Dynamic:
- ✅ **Auto-updates** when you add new content
- ✅ **Genre detection** finds all genres in your library
- ✅ **Smart sorting** by date, rating, etc.
- ✅ **No manual work** - everything is automatic!

## 🔧 Configuration

### TMDb API Key (Optional):

Want even better categorization? Add your TMDb API key!

1. **Get a free API key:**
   - Go to https://www.themoviedb.org
   - Create account
   - Go to Settings → API
   - Request API key (free!)

2. **Add to Bridge:**
   - Open Settings in web interface
   - Add TMDb API Key field
   - Save settings

3. **Benefits:**
   - Better genre detection
   - Enhanced metadata
   - More accurate categorization
   - (Coming soon: More TMDb features!)

## 📊 Category Types Explained

### Recently Added
- Shows your newest content
- Sorted by date added to Plex
- Last 50 items
- Updates automatically

### Recently Released
- Shows newest releases
- Sorted by original release/air date
- Great for finding latest movies/shows
- Last 50 items

### Highly Rated
- Your best content
- Sorted by Plex/user ratings
- Top 50 rated items
- Helps find quality content

### Genre Categories
- Auto-detected from your library
- One category per genre
- Up to 100 items per genre
- Based on Plex metadata

## 🚀 Updating Your Installation

### If Already Running:

```bash
# Stop service
sudo systemctl stop plex-xtream-bridge

# Backup
cd ~/plex-xtream-bridge
cp plex_xtream_bridge_web.py plex_xtream_bridge_web.py.backup
cp config.json config.json.backup

# Copy new version
# ... download/upload the new file ...

# Restart
sudo systemctl start plex-xtream-bridge
```

### After Update:

1. **Refresh your player** - Pull down to refresh or restart app
2. **Check categories** - Navigate to VOD/Series to see new categories
3. **Browse content** - Enjoy organized content!

## 🎬 Example Categories

If you have these genres in your library, you'll see:

### Movies:
- 🆕 Recently Added - Movies
- 🎬 Recently Released - Movies
- ⭐ Highly Rated - Movies
- 🎭 Action - Movies (153 movies)
- 🎭 Adventure - Movies (89 movies)
- 🎭 Animation - Movies (45 movies)
- 🎭 Comedy - Movies (201 movies)
- 🎭 Crime - Movies (67 movies)
- 🎭 Documentary - Movies (34 movies)
- 🎭 Drama - Movies (278 movies)
- 🎭 Fantasy - Movies (56 movies)
- 🎭 Horror - Movies (92 movies)
- 🎭 Mystery - Movies (43 movies)
- 🎭 Romance - Movies (87 movies)
- 🎭 Sci-Fi - Movies (110 movies)
- 🎭 Thriller - Movies (145 movies)
- 🎭 Western - Movies (28 movies)

### TV Shows:
- 🆕 Recently Added - TV Shows
- 📺 Recently Aired - TV Shows
- ⭐ Highly Rated - TV Shows
- 🎭 Action & Adventure - TV Shows
- 🎭 Animation - TV Shows
- 🎭 Comedy - TV Shows
- 🎭 Crime - TV Shows
- 🎭 Documentary - TV Shows
- 🎭 Drama - TV Shows
- 🎭 Family - TV Shows
- 🎭 Kids - TV Shows
- 🎭 Mystery - TV Shows
- 🎭 Sci-Fi & Fantasy - TV Shows

## 🧪 Testing

### Check Categories via API:

```bash
# Get movie categories
curl "http://localhost:8080/player_api.php?username=admin&password=admin&action=get_vod_categories"

# Get series categories
curl "http://localhost:8080/player_api.php?username=admin&password=admin&action=get_series_categories"

# You should see many more categories than before!
```

### Check Logs:

```bash
sudo journalctl -u plex-xtream-bridge -f
```

Look for:
```
✓ Loaded X movie categories and Y series categories
[API] Request: action=get_vod_categories, user=admin
```

## 💡 Tips & Tricks

### Organize Your Player:
- **Favorite categories** you use most
- **Hide categories** you don't need
- **Create groups** in TiviMate for better organization

### Best Practices:
- **Keep Plex metadata updated** - Better genres = Better categories
- **Use Plex collections** - They'll show as categories too
- **Rate your content** - Improves "Highly Rated" category

### Performance:
- Categories are **cached** for better performance
- First load might be slower as categories are built
- Subsequent loads are fast

## 🔮 Coming Soon

Future category features:

- **Custom Categories** - Create your own with filters
- **Year-Based** - Categories by decade (1980s, 1990s, etc.)
- **Actor/Director** - Categories for your favorite creators
- **Collections** - Movie collections (MCU, Star Wars, etc.)
- **Watch Status** - Unwatched, In Progress, Completed
- **TMDb Collections** - Automatic movie collections from TMDb
- **Advanced Filters** - Runtime, resolution, audio tracks

## ❓ FAQ

**Q: How many categories will I have?**
A: It depends on your library! Typically:
- 3 smart categories per library (Recently Added, Released, Rated)
- 1 category per genre (varies by library)
- Usually 15-30 total categories

**Q: Can I disable categories?**
A: Not yet, but it's coming! For now, all categories are shown.

**Q: Will this slow down my player?**
A: No! Categories are lightweight and load quickly.

**Q: Do categories update automatically?**
A: Yes! They're generated dynamically from your current library.

**Q: Can I rename categories?**
A: Not yet, but custom categories are coming soon!

**Q: What if I don't have genres in Plex?**
A: You'll still get Recently Added, Released, and Highly Rated categories.

**Q: Does this use TMDb?**
A: Not yet required, but adding TMDb API key will enable future features.

## 📝 Summary

Your bridge now has automatic smart categories that:
- ✅ Organize content intelligently
- ✅ Update dynamically
- ✅ Work with all Xtream players
- ✅ Require no manual configuration
- ✅ Include genre detection
- ✅ Support all your libraries

Just update the bridge and your content will be beautifully organized! 🎉

## 🎊 Enjoy!

Your movies and TV shows are now organized into helpful categories. Browse by genre, find recently added content, or check out your highest-rated items - all automatically organized for you!
