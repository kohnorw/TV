# 🐳 Portainer Deployment Guide

Complete guide to deploying Plex Xtream Bridge in Portainer.

## 📋 Prerequisites

- Portainer installed and running
- Access to Portainer web interface
- Docker environment configured in Portainer

## 🚀 Method 1: Deploy from Stack (Recommended)

### **Step 1: Build Custom Image First**

Since Portainer can't build images, you need to build it once on your Docker host:

```bash
# SSH to your server
ssh user@your-server

# Create directory
mkdir plex-xtream-bridge
cd plex-xtream-bridge

# Upload these files:
# - Dockerfile
# - plex_xtream_bridge_web.py
# - requirements.txt

# Build the image
docker build -t plex-xtream-bridge:latest .

# Verify image exists
docker images | grep plex-xtream-bridge
```

### **Step 2: Deploy Stack in Portainer**

1. **Login to Portainer** → `http://your-portainer-ip:9000`

2. **Go to Stacks** → Click "Add stack"

3. **Stack Details:**
   - **Name:** `plex-xtream-bridge`
   - **Build method:** Web editor

4. **Paste Stack Content:**

```yaml
version: '3.8'

services:
  plex-xtream-bridge:
    image: plex-xtream-bridge:latest
    container_name: plex-xtream-bridge
    restart: unless-stopped
    ports:
      - "8080:8080"
    volumes:
      - plex-bridge-data:/app/data
    environment:
      - PYTHONUNBUFFERED=1
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8080/player_api.php"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 40s

volumes:
  plex-bridge-data:
    driver: local
```

5. **Click "Deploy the stack"**

6. **Wait for deployment** (30-60 seconds)

7. **Access:** `http://YOUR_SERVER_IP:8080/admin`

## 🎯 Method 2: Deploy as Container

### **Step 1: Build Image** (same as Method 1)

### **Step 2: Create Container in Portainer**

1. **Go to Containers** → Click "Add container"

2. **Container Configuration:**

   **General Settings:**
   - **Name:** `plex-xtream-bridge`
   - **Image:** `plex-xtream-bridge:latest`
   
   **Network ports configuration:**
   - Click "+ publish a new network port"
   - **Host:** `8080`
   - **Container:** `8080`
   
   **Advanced container settings:**
   
   - **Volumes → Volume mapping:**
     - Click "+ map additional volume"
     - **Container:** `/app/data`
     - **Volume:** Create new volume `plex-bridge-data`
   
   - **Env → Environment variables:**
     - Click "+ add environment variable"
     - `PYTHONUNBUFFERED` = `1`
   
   - **Restart policy:**
     - Select "Unless stopped"
   
   - **Runtime & Resources:**
     - Leave defaults (or set limits if desired)

3. **Click "Deploy the container"**

4. **Access:** `http://YOUR_SERVER_IP:8080/admin`

## ⚙️ Method 3: Using Docker Hub (Future)

Once you publish the image to Docker Hub:

### **Stack Content:**

```yaml
version: '3.8'

services:
  plex-xtream-bridge:
    image: yourusername/plex-xtream-bridge:latest
    container_name: plex-xtream-bridge
    restart: unless-stopped
    ports:
      - "8080:8080"
    volumes:
      - plex-bridge-data:/app/data
    environment:
      - PYTHONUNBUFFERED=1

volumes:
  plex-bridge-data:
    driver: local
```

Then just deploy in Portainer → Stacks!

## 🔧 Configuration in Portainer

### **Environment Variables:**

In Portainer Stack, add to `environment:` section:

```yaml
environment:
  - PYTHONUNBUFFERED=1
  - PLEX_URL=http://192.168.1.100:32400
  - PLEX_TOKEN=your-plex-token
  - BRIDGE_USERNAME=myuser
  - BRIDGE_PASSWORD=mypassword
  - ADMIN_PASSWORD=admin-password
  - TMDB_API_KEY=your-tmdb-key
```

Or add via Portainer UI:
1. Go to **Containers**
2. Click your container
3. **Duplicate/Edit**
4. Scroll to **Env**
5. Add variables
6. **Deploy**

### **Using Portainer Secrets (More Secure):**

1. **Create Secret:**
   - Portainer → Secrets → Add secret
   - **Name:** `plex_token`
   - **Secret:** Your token
   - Save

2. **Use in Stack:**

```yaml
version: '3.8'

services:
  plex-xtream-bridge:
    image: plex-xtream-bridge:latest
    secrets:
      - plex_token
    environment:
      - PLEX_TOKEN_FILE=/run/secrets/plex_token

secrets:
  plex_token:
    external: true
```

## 📊 Managing in Portainer

### **View Logs:**
1. Containers → `plex-xtream-bridge`
2. Click "Logs" icon
3. Or click container → Logs tab

### **Restart Container:**
1. Containers → `plex-xtream-bridge`
2. Click "Restart" icon

### **Update Container:**
1. SSH to server
2. Rebuild image: `docker build -t plex-xtream-bridge:latest .`
3. Portainer → Containers → `plex-xtream-bridge`
4. Click "Recreate"
5. Enable "Pull latest image"
6. Click "Recreate"

### **Access Console:**
1. Containers → `plex-xtream-bridge`
2. Click "Console" icon
3. Connect as: `/bin/bash`

### **View Stats:**
1. Containers → `plex-xtream-bridge`
2. Click "Stats" icon
3. See CPU, Memory, Network

## 🔒 Security Settings

### **Access Control Lists (ACL):**

Restrict access using Portainer's network features:

1. **Create custom network:**
   - Networks → Add network
   - **Name:** `plex-internal`
   - **Driver:** bridge

2. **Update Stack:**

```yaml
services:
  plex-xtream-bridge:
    networks:
      - plex-internal

networks:
  plex-internal:
    external: true
```

### **Resource Limits:**

Add to stack:

```yaml
services:
  plex-xtream-bridge:
    deploy:
      resources:
        limits:
          cpus: '0.5'
          memory: 512M
        reservations:
          memory: 128M
```

## 📁 Volume Management

### **View Volume:**
1. Volumes → `plex-bridge-data`
2. See size, mount point

### **Backup Volume:**

```bash
# SSH to server
docker run --rm \
  -v plex-bridge-data:/data \
  -v $(pwd):/backup \
  alpine tar czf /backup/plex-bridge-backup.tar.gz /data
```

### **Restore Volume:**

```bash
docker run --rm \
  -v plex-bridge-data:/data \
  -v $(pwd):/backup \
  alpine tar xzf /backup/plex-bridge-backup.tar.gz -C /
```

### **Browse Volume Files:**
1. Volumes → `plex-bridge-data`
2. Click "Browse"
3. View/edit files (if enabled)

## 🔄 Update Process in Portainer

### **Step 1: Rebuild Image**
```bash
# SSH to server
cd plex-xtream-bridge
docker build -t plex-xtream-bridge:latest .
```

### **Step 2: Update in Portainer**

**Option A: Recreate Container**
1. Containers → `plex-xtream-bridge`
2. Stop container
3. Remove container
4. Redeploy stack (or recreate container)

**Option B: Update Stack**
1. Stacks → `plex-xtream-bridge`
2. Click "Editor"
3. No changes needed
4. Click "Update the stack"
5. Enable "Re-pull image and redeploy"
6. Click "Update"

## 🎨 Portainer Templates (Advanced)

Create a custom template for easy deployment:

1. **Go to:** Settings → App Templates

2. **Add Template:**

```json
{
  "type": 3,
  "title": "Plex Xtream Bridge",
  "description": "Bridge between Plex and Xtream Codes API",
  "note": "Requires pre-built image: plex-xtream-bridge:latest",
  "categories": ["Media"],
  "platform": "linux",
  "logo": "https://raw.githubusercontent.com/plexinc/plex-media-player/master/resources/images/icon.png",
  "repository": {
    "url": "https://github.com/yourusername/plex-xtream-bridge",
    "stackfile": "portainer-stack.yml"
  },
  "env": [
    {
      "name": "PLEX_URL",
      "label": "Plex Server URL",
      "description": "URL to your Plex server (e.g., http://192.168.1.100:32400)"
    },
    {
      "name": "PLEX_TOKEN",
      "label": "Plex Token",
      "description": "Your Plex authentication token"
    },
    {
      "name": "BRIDGE_USERNAME",
      "label": "Bridge Username",
      "default": "admin",
      "description": "Username for Xtream player authentication"
    },
    {
      "name": "BRIDGE_PASSWORD",
      "label": "Bridge Password",
      "description": "Password for Xtream player authentication"
    }
  ],
  "volumes": [
    {
      "container": "/app/data",
      "bind": "plex-bridge-data"
    }
  ],
  "ports": [
    "8080:8080/tcp"
  ]
}
```

3. **Deploy from Templates:**
   - Home → App Templates
   - Find "Plex Xtream Bridge"
   - Fill in variables
   - Deploy!

## 📊 Monitoring in Portainer

### **Container Health:**
- Green dot = Healthy
- Yellow dot = Unhealthy
- Red dot = Down

### **Quick Stats:**
- CPU usage
- Memory usage
- Network I/O
- Uptime

### **Alerts (Portainer Business):**
Set up webhook alerts for:
- Container down
- High CPU/memory
- Health check failures

## 🐛 Troubleshooting

### **Container Won't Start:**

1. **Check logs:**
   - Containers → `plex-xtream-bridge` → Logs

2. **Common issues:**
   - Port 8080 in use
   - Image not found
   - Volume permissions

### **Can't Access Web Interface:**

1. **Check container status:**
   - Should show "running" and "healthy"

2. **Check port mapping:**
   - Containers → `plex-xtream-bridge` → Inspect
   - Look for port bindings

3. **Test from server:**
   ```bash
   curl http://localhost:8080/admin
   ```

### **Configuration Not Persisting:**

1. **Check volume mount:**
   - Containers → `plex-xtream-bridge` → Inspect
   - Look for volume mounts

2. **Verify volume exists:**
   - Volumes → `plex-bridge-data`

## 📋 Complete Setup Checklist

- [ ] Portainer installed and running
- [ ] Built Docker image on host
- [ ] Created stack or container in Portainer
- [ ] Configured ports (8080)
- [ ] Created volume (plex-bridge-data)
- [ ] Set environment variables (optional)
- [ ] Deployed container
- [ ] Verified container is running
- [ ] Accessed web interface
- [ ] Changed default passwords
- [ ] Configured Plex connection
- [ ] Tested movie playback
- [ ] Tested TV show playback

## 🎉 Summary

Portainer deployment offers:
- ✅ **Visual interface** - No command line needed
- ✅ **Easy management** - Click to restart, update, view logs
- ✅ **Monitoring** - Built-in stats and health checks
- ✅ **Templates** - Reusable configurations
- ✅ **Access control** - User permissions
- ✅ **Backups** - Volume management

Your bridge is now running in Portainer! 🎬
