# 🔒 Security Features Guide

## 🎉 What's New

Your Plex Xtream Bridge now has **enterprise-grade security features** to protect your sensitive data!

## 🛡️ Security Features

### 1. Encryption for Sensitive Data
- ✅ **Plex Token** - Encrypted before saving
- ✅ **TMDb API Key** - Encrypted before saving  
- ✅ **AES-256 Encryption** - Industry standard
- ✅ **Unique Encryption Key** - Generated per installation

### 2. Password Hashing
- ✅ **SHA-256 Hashing** - Passwords never stored in plain text
- ✅ **One-way Hash** - Passwords cannot be decrypted
- ✅ **Secure Verification** - Hash comparison for login

### 3. File Permissions
- ✅ **Restricted Access** - Config files set to 600 (owner only)
- ✅ **Key Protection** - Encryption key protected
- ✅ **Secure Storage** - Sensitive data locked down

### 4. Forced Password Change
- ✅ **First Login** - Must change default password
- ✅ **Minimum Length** - 8 characters required
- ✅ **Validation** - Prevents weak passwords

## 🔐 First Time Setup

### What Happens on First Login:

1. Enter default password: `admin123`
2. Automatic redirect to password change page
3. Create secure password (minimum 8 characters)
4. Confirm password
5. Password is hashed and config is encrypted
6. Continue to dashboard

## 🚀 Installing/Updating

### Install new dependency:
```bash
pip install cryptography

# Or use requirements.txt:
pip install -r requirements.txt
```

### On first run:
- Encryption key is generated automatically
- Old configs are migrated and encrypted
- You'll be forced to change default password

## 🔒 What Gets Encrypted

Your config.json will look like:
```json
{
  "plex_token": "gAAAAABh5Q...",      // ← Encrypted
  "tmdb_api_key": "gAAAAABh5Q...",    // ← Encrypted  
  "admin_password": "5e884898da...",  // ← Hashed
  "bridge_username": "admin",         // Plain (not sensitive)
  "plex_url": "http://..."            // Plain (not sensitive)
}
```

## 📁 File Security

Files are automatically secured:
```bash
-rw------- config.json           # 600 - Owner only
-rw------- .encryption_key       # 600 - Owner only
```

## 💡 Password Requirements

- Minimum 8 characters
- Cannot be "admin123"
- Must match confirmation

## 🔄 Updating from Old Version

```bash
# Stop service
sudo systemctl stop plex-xtream-bridge

# Backup config
cp config.json config.json.backup

# Install cryptography
source venv/bin/activate
pip install cryptography

# Copy new bridge file
# (your updated plex_xtream_bridge_web.py)

# Start service
sudo systemctl start plex-xtream-bridge
```

On first login after update, you'll be asked to change your password.

## ❓ Troubleshooting

### Forgot Password?
```bash
cd ~/plex-xtream-bridge
rm config.json
sudo systemctl restart plex-xtream-bridge
# Default password restored: admin123
```

### Encryption Error?
```bash
# If encryption key is lost, you'll need to reconfigure
rm config.json .encryption_key
sudo systemctl restart plex-xtream-bridge
```

## ✅ Security Checklist

After installation:
- ✅ Changed default password
- ✅ Password is 8+ characters
- ✅ config.json has 600 permissions
- ✅ Can login with new password
- ✅ Backed up config files

## 🎉 Summary

Your bridge now has:
- 🔒 Encrypted API keys and tokens
- 🔒 Hashed passwords
- 🔒 Restricted file permissions
- 🔒 Forced password changes
- 🔒 Secure by default
