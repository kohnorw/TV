# How to Change Xtream UI Username & Password

## ✨ What's New?

The updated version now allows you to **easily change your Xtream UI credentials** through the web interface!

## 🔄 Updating Your Installation

### If You're Already Running the Bridge:

1. **Stop the service:**
   ```bash
   sudo systemctl stop plex-xtream-bridge
   ```

2. **Backup your config (optional but recommended):**
   ```bash
   cd ~/plex-xtream-bridge
   cp config.json config.json.backup
   ```

3. **Download the updated version:**
   ```bash
   cd ~/plex-xtream-bridge
   
   # If from GitHub:
   curl -L -o plex_xtream_bridge_web.py "https://raw.githubusercontent.com/YOUR_USERNAME/YOUR_REPO/main/plex_xtream_bridge_web.py"
   
   # Or use scp if you downloaded locally:
   # scp plex_xtream_bridge_web.py username@server-ip:~/plex-xtream-bridge/
   ```

4. **Restart the service:**
   ```bash
   sudo systemctl start plex-xtream-bridge
   ```

5. **Check status:**
   ```bash
   sudo systemctl status plex-xtream-bridge
   ```

## 🎯 How to Change Credentials

### Via Web Interface (Easy!)

1. **Access the admin panel:**
   ```
   http://YOUR_SERVER_IP:8080/admin
   ```

2. **Login** with your admin password

3. **Click "⚙️ Settings"**

4. **Find the "Xtream UI Player Credentials" section**

5. **Change the username and password** to whatever you want:
   - Username: `myusername` (can be anything)
   - Password: `mysecurepassword123` (can be anything)

6. **Click "💾 Save Settings"**

7. **Update your player app** with the new credentials!

### What You'll See:

The Settings page now has a dedicated section called **"Xtream UI Player Credentials"** where you can:
- Set any username you want
- Set any password you want
- See a reminder to update your player app after changing

### Important Notes:

- ✅ Your existing config.json will be preserved
- ✅ Your Plex connection stays the same
- ✅ Changes take effect immediately
- ⚠️ You'll need to update your Xtream UI player with the new credentials

## 📱 Updating Your Player App

After changing credentials, update your Xtream UI player:

### TiviMate:
1. Settings → Playlists
2. Select your Plex Bridge playlist
3. Edit → Update username/password
4. Save

### IPTV Smarters Pro:
1. Settings → User Info
2. Edit user
3. Update username/password
4. Save

### GSE Smart IPTV:
1. Edit playlist
2. Update credentials
3. Save

## 🆕 New Features in This Update:

1. **Editable Xtream Credentials** - Change username/password anytime
2. **Better Settings UI** - Clearer labels and instructions
3. **Input Validation** - Won't let you save empty credentials
4. **Quick Start Guide** - Dashboard now shows setup steps
5. **Visual Improvements** - Credentials are highlighted on dashboard

## 🧪 Testing After Update:

```bash
# Test the API with new credentials
curl "http://YOUR_SERVER_IP:8080/player_api.php?username=YOUR_NEW_USERNAME&password=YOUR_NEW_PASSWORD"

# You should see a JSON response with auth: 1
```

## 💡 Example Use Cases:

**Multiple Users:**
You could create separate instances with different credentials for different family members.

**Security:**
Change credentials regularly or after sharing with someone temporarily.

**Easy to Remember:**
Use credentials that make sense to you instead of "admin/admin".

## 🔒 Security Best Practices:

1. **Use strong passwords** - Not "admin" or "password"
2. **Use unique credentials** - Different from your Plex password
3. **Change the admin password** - Protect the web interface
4. **Consider firewall rules** - Limit access to trusted networks

## ❓ Troubleshooting:

**Players won't connect after changing:**
- Make sure you updated the credentials in your player app
- Test the API endpoint in a browser
- Check the logs: `sudo journalctl -u plex-xtream-bridge -f`

**Forgot your new credentials:**
- Check the dashboard: `http://YOUR_SERVER_IP:8080/admin`
- Or check config.json: `cat ~/plex-xtream-bridge/config.json`

**Want to reset everything:**
```bash
cd ~/plex-xtream-bridge
rm config.json
sudo systemctl restart plex-xtream-bridge
# Then reconfigure through web interface
```

## 📝 Manual Configuration (Advanced)

If you prefer to edit config.json directly:

```bash
nano ~/plex-xtream-bridge/config.json
```

Change:
```json
{
  "bridge_username": "your_new_username",
  "bridge_password": "your_new_password"
}
```

Restart:
```bash
sudo systemctl restart plex-xtream-bridge
```

## 🎉 Enjoy!

You can now easily manage your Xtream UI credentials through the web interface. No more editing config files!
